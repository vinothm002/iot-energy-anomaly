# Industrial Asset Energy & Anomaly Detection

Synthetic telemetry for **Chiller-01, Compressor-02, Pump-03** -> cleaning -> hybrid anomaly detector
-> excess-energy / cost / root-cause insights -> FastAPI service + dashboard.

## Quickstart

```bash
./run.sh              # creates .venv, installs, trains if needed, serves http://localhost:8000
./run.sh pipeline     # regenerate data -> clean -> train -> charts -> insights -> report
./run.sh test         # pytest tests/
docker compose up --build        # alternative: same service in Docker
```
Requires Python >= 3.11 (pandas 3). On Windows use WSL or Docker for `run.sh`; or run the modules
directly: `python -m src.pipeline` then `uvicorn src.main:app`.

```bash
curl -X POST localhost:8000/api/v1/diagnose -H 'content-type: application/json' -d '{
 "timestamp":"2026-10-01T14:30:00Z","asset_id":"Chiller-01","power_kw":285.5,"flow_rate":450.0,
 "supply_temp_c":7.2,"return_temp_c":12.8,"pressure_bar":4.2,"status":"RUNNING"}'
curl -F file=@data/raw_telemetry.csv "localhost:8000/api/v1/batch-audit?report=true"
curl localhost:8000/health          # dashboard at /, Swagger at /docs
```
> The sample payload from the brief draws 285.5 kW at 450 GPM, but the healthy curve for that flow is
> ~230 kW, so it is correctly returned as **CRITICAL / POWER_SURGE (+24%)**.

## Layout

| Path | Role |
|---|---|
| `src/generate_data.py` | synthetic 7-day, 1-min data + dirty-data injection + ground-truth labels |
| `src/data_processor.py` | validation, grid restore, bounds, freeze flags, imputation, features |
| `src/detector.py` | hybrid detector (Isolation Forest + physics baseline + drift + rules), diagnostics |
| `src/train.py` | fit per asset, calibrate, save `models/anomaly_detector.joblib`, evaluate |
| `src/evaluate.py` | metrics vs injected faults, ablation, threshold sweep |
| `src/insights.py` | excess kWh, $ cost, root cause, shift handoff (optional LLM) |
| `src/visualize.py` | charts in `outputs/` |
| `src/service.py` / `src/main.py` | API logic (framework-free, unit-tested) / FastAPI wrapper |
| `src/dashboard.py` | results page at `/` and `outputs/report.html` |
| `tests/` | 36 unit tests + HTTP tests (`test_api.py`) |

## Data and cleaning (Task 1)

Each machine has a 7-day grid of 10,080 minutes. Injected: 15-30 min dropouts (rows deleted **and** NaN
blocks), negative power, 999 C / -40 C spikes, three 50-60 min temperature freezes while RUNNING, a
22-25% power rise over 48 h at constant flow (drift), and three 20-25 min power surges.
The raw file therefore has ~10,060 rows per machine (deleted rows *are* the missing-timestamp defect);
`data/cleaned_telemetry.csv` has exactly 10,080.

Cleaning: timestamps floored to the minute and de-duplicated; coarser-than-1-min input is **rejected**
(re-sampling would fabricate data); missing minutes restored; out-of-bounds values -> NaN with a flag;
`rolling(30).std() < 1e-6` while RUNNING flags freezes; gaps <= 30 min time-interpolated (longer stay
NaN and are flagged); bad/missing `status` becomes NaN then `UNKNOWN` (never crashes boolean masks).
Features: `delta_t`, `specific_energy`, `rolling_power_mean_1h`, `load_ratio`.

## Model (Task 2)

Per asset, trained on **healthy RUNNING data from the first 2.5 days only** (freezes, outliers and
imputed rows excluded):

1. **Isolation Forest** (300 trees) on power, flow, delta_t, specific energy, pressure, power residual.
   `load_ratio` is *not* a model input: it is `power / constant`, i.e. a rescaled duplicate of power.
2. **Physics baseline**: cubic fit of power vs flow; residual z-score vs MAD-estimated noise.
   Flow is clamped to the trained range so the cubic cannot extrapolate.
3. **Drift**: 24 h rolling median of the residual (RUNNING minutes only).
4. **Rules**: out-of-bounds readings and frozen probes.

Score = max of the components, mapped to 0-1: NORMAL < 0.50, WARNING 0.50-0.75, CRITICAL >= 0.75.
Alarm = 5-minute rolling median >= 0.50 (persistence filter), plus any out-of-range reading.
Frozen-probe minutes zero the ML component (their `delta_t` is corrupted) but the physics residual
still runs, so a surge during a freeze is still detected and costed.
STANDBY/OFF are never scored, so idle periods are not false alarms.

**Calibration.** The last 20% of the reference window is held out and used only to map raw forest
scores to 0-1. A first version used the 99.5th percentile of that data as the WARNING point; that
flags ~0.5% of healthy minutes by construction and gave 2.59 false alarms/asset-day. WARNING is now
"more unusual than anything in the held-out healthy data (+25% margin)". **That margin was chosen after
looking at hold-out results**, which is why a fresh-seed dataset is reported as the unbiased check.

## Results

Full tables: `outputs/evaluation.md`. Alarm threshold 0.50 (the spec's WARNING boundary), 5-min persistence.

| | Hold-out (days 3.5-7) | Fresh dataset (seed 43) |
|---|---:|---:|
| Surge event recall / minute recall | 3/3 / 91% | 3/3 / 91% |
| Freeze event recall / minute recall | 2/2 / 98% | 3/3 / 98% |
| Drift event recall / minute recall | 2/2 / 97% | 2/2 / 97% |
| Precision (alarm minutes in a fault window) | 99.8% | 99.8% |
| False-alarm episodes per asset-day | 0.52 | 0.19 |
| Physical outliers (hard rule) | 31/31 | 54/54 |

- Surges are flagged within ~2 min; freezes within ~1-2 min of the 30-sample window completing.
- **Drift is slow by nature**: first alarms at ~2-8 h (rise 1-4%, partly noise), *sustained* alarm after
  ~12 h (5-7% rise), explicit "gradual thermal efficiency loss" diagnosis after ~28 h (13-15%).
- **Energy accuracy**: estimated drift waste was 2,619 kWh (Chiller) and 578 kWh (Compressor) vs the
  injected ground truth of 2,637 and 591 kWh (-0.7% / -2.1%); a test enforces <10%.
- **Ablation**: physics-only gets the same recall as the hybrid on these faults; ML-only has lower recall
  (59% minute recall) but very few false alarms (0.07/asset-day). On this synthetic data the physics
  baseline does the heavy lifting; the forest's value is coverage of deviations the power-vs-flow model
  cannot see (pressure, delta_t, odd operating points) - none of which are injected here, so that benefit
  is **not demonstrated** by these numbers.

### Precision vs recall - why false alarms are costly, and the threshold

A false alarm sends a technician to a healthy machine, can trigger an unnecessary shutdown of
production equipment, and above all trains operators to ignore alarms - so the real fault gets ignored
too. A missed fault costs energy (drift) or equipment (surge, frozen probe). The sweep in
`outputs/evaluation.md` / `precision_recall.png` shows the trade-off: below 0.45 precision collapses
(13 false alarms/asset-day at 0.30); at 0.65+ recall of the slow drift drops (event recall 83%) because
the drift score sits between 0.5 and 0.75 for hours. **0.50 is the brief's WARNING boundary and also the
knee of the curve**: ~95% minute recall at ~0.5 false alarms/asset-day. The persistence filter (5 min)
trades ~2-5 minutes of delay for far fewer one-minute noise alarms. Out-of-range values bypass it.

## Insights (Task 3)

For each alarm episode: baseline kW at the actual flow, `excess kWh = sum(actual - baseline) / 60`,
cost at **$0.12/kWh** (`TARIFF_USD_PER_KWH` overrides). Events merge by wall-clock minutes (never across
standby), `duration_min` is wall-clock, and no minute is costed twice. Drift is costed **retroactively**
from the estimated onset (6 h median residual first > 2%), not just from its first alarm. Messages follow the brief
(surge / freeze / drift) with an asset-specific maintenance action for drift. The optional LLM handoff
(`ANTHROPIC_API_KEY`, `LLM_MODEL`) sends the diagnostics summary to an external API; `DISABLE_LLM=1` keeps it local.
The drift heuristic uses a load-adjusted power residual instead of raw `specific_energy`, so a load
change is not mistaken for degradation.

## API notes

`/diagnose` is single-reading (no history): freezes and drift need `/batch-audit`. Impossible values
(negative power, 999 C) are accepted and reported as `DATA_QUALITY`, not rejected. `/batch-audit` accepts a
CSV (`file` field) or a JSON array; both paths tolerate nulls/unknown labels identically. Heavy work runs
in a thread pool. Limits: 50,000 rows, 20 MB. The dashboard's evaluation tables describe the generated
dataset only and are hidden after an upload.

## Known limitations

- All data is synthetic and the detector's thresholds were developed on it; real plants will need
  re-calibration and a real healthy reference window. Results above are not evidence of field accuracy.
- Hold-out and fresh-seed data share the generator's noise model with the training data.
- Model files are `joblib` (pickle): only load files you trained. No authentication or rate limiting.
- The raw sample payload's drift detection needs >= 6 h of history in a batch; a 24 h batch is sufficient.
- `requirements.txt` pins the data/ML stack exactly (tested); the web/test stack is range-pinned.
  The FastAPI layer (`src/main.py`, `tests/test_api.py`) was written and syntax-checked but **not executed**
  where this was authored (no FastAPI/pytest available offline); its logic lives in `src/service.py`,
  which is covered by the 36 tests that were run. Run `./run.sh test` once to confirm the HTTP tests.
