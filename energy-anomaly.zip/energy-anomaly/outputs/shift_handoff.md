SHIFT HANDOFF - Asset Energy & Maintenance
- Records analysed: 30,240; alarm episodes: 75
- Excess energy: 3,258.6 kWh (~$391.03 at $0.12/kWh)

Maintenance - priority items:
- [CRITICAL] Chiller-01 2026-10-05T12:40:00Z -> 2026-10-07T23:59:00Z (3560 min, 2618.59 kWh / $314.23): Gradual thermal efficiency loss detected (+25% above baseline). Recommend inspecting heat exchanger tubes for fouling or refrigerant leak.
- [CRITICAL] Compressor-02 2026-10-06T05:02:00Z -> 2026-10-07T23:59:00Z (2578 min, 578.28 kWh / $69.39): Gradual thermal efficiency loss detected (+22% above baseline). Recommend inspecting compressor seals, intake filter and downstream air leaks.
- [CRITICAL] Chiller-01 2026-10-04T16:02:00Z -> 2026-10-04T16:26:00Z (25 min, 43.76 kWh / $5.25): High power surge detected without proportional flow increase. Check electrical motor load or compressor stage bypass.
- [CRITICAL] Compressor-02 2026-10-05T11:02:00Z -> 2026-10-05T11:21:00Z (20 min, 12.43 kWh / $1.49): High power surge detected without proportional flow increase. Check electrical motor load or compressor stage bypass.
- [CRITICAL] Pump-03 2026-10-07T14:32:00Z -> 2026-10-07T14:51:00Z (20 min, 5.49 kWh / $0.66): High power surge detected without proportional flow increase. Check electrical motor load or compressor stage bypass.
- [WARNING] Compressor-02 2026-10-04T05:55:00Z -> 2026-10-04T05:57:00Z (3 min, 0.06 kWh / $0.01): Operating point outside the learned normal envelope. Review recent setpoint changes and inspect the asset.
- ...and 12 short low-impact episodes (see full audit).

Instrumentation - data quality:
- Pump-03 2026-10-02T09:00:00Z -> 2026-10-02T09:59:00Z (60 min): Sensor freeze detected on temperature probe. Possible thermocouple failure or communication loop lockup.
- Compressor-02 2026-10-04T15:00:00Z -> 2026-10-04T15:54:00Z (55 min): Sensor freeze detected on temperature probe. Possible thermocouple failure or communication loop lockup.
- Chiller-01 2026-10-06T10:00:00Z -> 2026-10-06T10:49:00Z (50 min): Sensor freeze detected on temperature probe. Possible thermocouple failure or communication loop lockup.
- 54 out-of-range readings discarded (Chiller-01, Compressor-02, Pump-03): Sensor reading outside physical limits (e.g. negative power or impossible temperature). Value discarded; check sensor wiring and transmitter.
