## Evaluation

### A. Temporal hold-out (model trained on first 2.5 days; scored on the rest)

Window: 2026-10-03 12:00 -> 2026-10-07 23:59 UTC; alarm = 5-minute median of score >= 0.50

| Injected fault | Events | Detected | Event recall | Minute recall | Median delay (min from onset) |
|---|---:|---:|---:|---:|---:|
| Power surge | 3 | 3 | 100% | 91% | 2 |
| Frozen sensor | 2 | 2 | 100% | 98% | 1 |
| Efficiency drift | 2 | 2 | 100% | 97% | 710 |
| Physical outlier (rule) | 31 | 31 | 100% | 100% | 0 |

- Macro recall over surge/freeze/drift: event **100%**, minute **95.2%**
- Alarm minutes 5,816, inside an expected-fault window 5,803 -> **precision 99.8%**
- False-alarm episodes: 7 (**0.52 per asset-day**)

| Drift | First alarm (h) | Rise then | Sustained alarm (h) | Rise then | Drift diagnosis (h) | Rise then |
|---|---:|---:|---:|---:|---:|---:|
| Chiller-01 | 6.8 | 3.6% | 11.8 | 6.1% | 28.3 | 14.7% |
| Compressor-02 | 2.1 | 0.9% | 11.8 | 5.4% | 28.2 | 12.9% |


### B. Fresh dataset (seed 43, never seen in training)

Window: 2026-10-01 00:00 -> 2026-10-07 23:59 UTC; alarm = 5-minute median of score >= 0.50

| Injected fault | Events | Detected | Event recall | Minute recall | Median delay (min from onset) |
|---|---:|---:|---:|---:|---:|
| Power surge | 3 | 3 | 100% | 91% | 2 |
| Frozen sensor | 3 | 3 | 100% | 98% | 2 |
| Efficiency drift | 2 | 2 | 100% | 97% | 738 |
| Physical outlier (rule) | 54 | 54 | 100% | 100% | 0 |

- Macro recall over surge/freeze/drift: event **100%**, minute **95.0%**
- Alarm minutes 5,904, inside an expected-fault window 5,894 -> **precision 99.8%**
- False-alarm episodes: 4 (**0.19 per asset-day**)

| Drift | First alarm (h) | Rise then | Sustained alarm (h) | Rise then | Drift diagnosis (h) | Rise then |
|---|---:|---:|---:|---:|---:|---:|
| Chiller-01 | 7.9 | 4.1% | 12.8 | 6.7% | 28.1 | 14.7% |
| Compressor-02 | 5.5 | 2.5% | 11.8 | 5.4% | 28.0 | 12.8% |


### Ablation (hold-out window): is the Isolation Forest earning its place?

| Variant | Precision | Event recall | Minute recall | False alarms / asset-day |
|---|---:|---:|---:|---:|
| hybrid (ML + physics + rules) | 99.8% | 100% | 95.2% | 0.52 |
| ML only (Isolation Forest + rules) | 99.8% | 89% | 59.0% | 0.07 |
| physics only (baseline residual + drift + rules) | 99.8% | 100% | 95.2% | 0.44 |

### Threshold sweep (hold-out window)

| Threshold | Precision | Minute recall | Event recall | False alarms / asset-day |
|---:|---:|---:|---:|---:|
| 0.30 | 70.9% | 97.9% | 100% | 13.26 |
| 0.35 | 83.5% | 97.5% | 100% | 7.33 |
| 0.40 | 92.3% | 96.1% | 100% | 4.52 |
| 0.45 | 97.7% | 95.6% | 100% | 1.85 |
| 0.50 **(spec boundary)** | 99.8% | 95.2% | 100% | 0.52 |
| 0.55 | 100.0% | 94.8% | 100% | 0.07 |
| 0.60 | 100.0% | 94.2% | 100% | 0.00 |
| 0.65 | 100.0% | 76.9% | 83% | 0.00 |
| 0.70 | 100.0% | 76.1% | 83% | 0.00 |
| 0.75 | 100.0% | 75.2% | 83% | 0.00 |
| 0.80 | 100.0% | 73.6% | 83% | 0.00 |
| 0.85 | 100.0% | 71.6% | 83% | 0.00 |
| 0.90 | 100.0% | 70.1% | 83% | 0.00 |
