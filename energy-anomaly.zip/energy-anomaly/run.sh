#!/usr/bin/env bash
# One-command runner.   ./run.sh            -> install, (train if no model yet), serve on :8000
#                       ./run.sh pipeline   -> regenerate data, train, charts, insights, report
#                       ./run.sh test       -> pytest tests/
# Env: PORT (8000), PYTHON (python3), NO_VENV=1 (use current interpreter, e.g. inside Docker)
set -euo pipefail
cd "$(dirname "$0")"
PY="${PYTHON:-python3}"

if [ "${NO_VENV:-0}" != "1" ]; then
  [ -d .venv ] || "$PY" -m venv .venv
  # shellcheck disable=SC1091
  . .venv/bin/activate
  pip install -q -r requirements.txt
fi

case "${1:-serve}" in
  pipeline) python -m src.pipeline ;;
  test)     python -m pytest tests/ -v ;;
  serve)
    [ -f models/anomaly_detector.joblib ] && [ -f data/scored_telemetry.csv ] || python -m src.pipeline
    exec uvicorn src.main:app --host 0.0.0.0 --port "${PORT:-8000}"
    ;;
  *) echo "usage: ./run.sh [serve|pipeline|test]"; exit 2 ;;
esac
