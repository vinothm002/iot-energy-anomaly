"""HTTP-level tests (require fastapi + httpx; skipped otherwise)."""
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")

from fastapi.testclient import TestClient  # noqa: E402

from src.main import app  # noqa: E402
from tests.conftest import reading_from  # noqa: E402

HEALTHY = "2026-10-02 12:00:00"


@pytest.fixture()
def client(detector):
    with TestClient(app) as c:
        app.state.detector = detector
        yield c


def test_health_ok(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["model_loaded"] is True


def test_health_503_without_model(client):
    app.state.detector = None
    assert client.get("/health").status_code == 503
    assert client.post("/api/v1/diagnose", json={}).status_code in (422, 503)


def test_diagnose_spec_payload_shape(client, dataset):
    r = client.post("/api/v1/diagnose", json=reading_from(dataset["clean"], "Chiller-01", HEALTHY))
    body = r.json()
    assert r.status_code == 200
    assert {"anomaly_score", "classification", "diagnosis", "diagnosis_code"} <= set(body)
    assert body["classification"] == "NORMAL"


def test_diagnose_surge_and_validation(client, dataset):
    p = reading_from(dataset["clean"], "Chiller-01", HEALTHY)
    p["power_kw"] *= 1.5
    assert client.post("/api/v1/diagnose", json=p).json()["diagnosis_code"] == "POWER_SURGE"
    bad = dict(p, asset_id="Boiler-99")
    assert client.post("/api/v1/diagnose", json=bad).status_code == 422
    assert client.post("/api/v1/diagnose", json=dict(p, status="BROKEN")).status_code == 422


def test_batch_audit_csv_upload_and_json(client, dataset):
    raw = dataset["raw"]
    day = raw[raw["timestamp"].str.startswith("2026-10-04")]
    r = client.post("/api/v1/batch-audit", files={"file": ("day.csv", day.to_csv(index=False), "text/csv")})
    assert r.status_code == 200 and r.json()["excess_energy_kwh"] > 0
    rows = day.head(300).astype(object).where(day.head(300).notna(), None).to_dict("records")   # nulls allowed
    r = client.post("/api/v1/batch-audit?report=true", json=rows)
    assert r.status_code == 200 and "shift_handoff" in r.json()
    assert client.post("/api/v1/batch-audit", content="x", headers={"content-type": "text/plain"}).status_code == 415
    assert client.post("/api/v1/batch-audit", json=[]).status_code == 422


def test_dashboard_served(client):
    r = client.get("/")
    assert r.status_code == 200 and "Anomaly Report" in r.text
