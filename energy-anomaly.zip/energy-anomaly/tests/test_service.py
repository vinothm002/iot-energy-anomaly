"""API logic without the web framework (so it runs even where FastAPI is not installed)."""
import io

import numpy as np
import pandas as pd
import pytest

from src.service import ServiceError, batch_audit_frame, diagnose_reading, parse_csv
from tests.conftest import reading_from

HEALTHY = "2026-10-02 12:00:00"


def test_diagnose_healthy_reading_is_normal(dataset, detector):
    out = diagnose_reading(detector, reading_from(dataset["clean"], "Chiller-01", HEALTHY))
    assert out["classification"] == "NORMAL" and out["anomaly_score"] < 0.5
    assert out["diagnosis_code"] == "NORMAL" and abs(out["power_residual_pct"]) < 0.06


def test_diagnose_power_surge_without_flow_increase(dataset, detector):
    r = reading_from(dataset["clean"], "Chiller-01", HEALTHY)
    r["power_kw"] *= 1.45
    out = diagnose_reading(detector, r)
    assert out["classification"] in ("WARNING", "CRITICAL") and out["diagnosis_code"] == "POWER_SURGE"
    assert "proportional flow increase" in out["diagnosis"] and out["excess_kw"] > 50


def test_diagnose_impossible_values_are_data_quality_not_crash(dataset, detector):
    for field, value in (("power_kw", -25.0), ("return_temp_c", 999.0)):
        r = reading_from(dataset["clean"], "Pump-03", HEALTHY)
        r[field] = value
        out = diagnose_reading(detector, r)
        assert out["diagnosis_code"] == "DATA_QUALITY" and out["classification"] in ("WARNING", "CRITICAL")


def test_diagnose_standby_is_not_an_anomaly(dataset, detector):
    r = reading_from(dataset["clean"], "Compressor-02", "2026-10-02 02:00:00")
    out = diagnose_reading(detector, r)
    assert r["status"] == "STANDBY" and out["classification"] == "NORMAL" and out["diagnosis_code"] == "NOT_RUNNING"


def test_diagnose_unknown_asset_is_a_422(detector, dataset):
    r = reading_from(dataset["clean"], "Chiller-01", HEALTHY)
    r["asset_id"] = "Boiler-99"
    with pytest.raises(ServiceError) as e:
        diagnose_reading(detector, r)
    assert e.value.status == 422


def _day(raw: pd.DataFrame, date: str) -> pd.DataFrame:
    t = pd.to_datetime(raw["timestamp"], utc=True)
    return raw[(t >= pd.Timestamp(date, tz="UTC")) & (t < pd.Timestamp(date, tz="UTC") + pd.Timedelta(days=1))]


def test_batch_audit_24h_finds_surge_freeze_and_costs_it(dataset, detector):
    day = _day(dataset["raw"], "2026-10-04")                 # Chiller surge 16:00, Compressor freeze 15:00
    out = batch_audit_frame(detector, day)
    kinds = {(e["asset_id"], e["root_cause"]) for e in out["flagged_intervals"]}
    assert ("Chiller-01", "POWER_SURGE") in kinds and ("Compressor-02", "SENSOR_FREEZE") in kinds
    assert out["excess_energy_kwh"] > 30 and out["estimated_cost_usd"] == pytest.approx(out["excess_energy_kwh"] * 0.12, abs=0.01)
    assert out["total_records"] == 3 * 1440 and out["anomalous_records"] > 0
    assert out["data_quality"]["input_rows"] <= out["total_records"]


def test_batch_audit_json_style_nulls_behave_like_csv(dataset, detector):
    day = _day(dataset["raw"], "2026-10-04").copy()
    day.loc[day.index[100:110], ["power_kw", "flow_rate"]] = None      # dropout as nulls
    out = batch_audit_frame(detector, day)
    assert out["total_records"] == 3 * 1440


def test_batch_audit_csv_roundtrip(dataset, detector):
    buf = io.BytesIO(_day(dataset["raw"], "2026-10-05").to_csv(index=False).encode())
    out = batch_audit_frame(detector, parse_csv(buf.getvalue()), include_report=True)
    assert "shift_handoff" in out and out["window"]["start"].startswith("2026-10-05")


def test_batch_audit_input_errors(detector, dataset):
    with pytest.raises(ServiceError) as e:
        batch_audit_frame(detector, pd.DataFrame(columns=["timestamp"]))
    assert e.value.status == 422
    with pytest.raises(ServiceError) as e:
        batch_audit_frame(detector, dataset["raw"].drop(columns=["status"]))
    assert e.value.status == 422 and "missing columns" in e.value.detail
    with pytest.raises(ServiceError) as e:
        parse_csv(b"\x00\x01 not,a\ncsv\xff" * 3 + b'"unterminated')
    assert e.value.status == 422
