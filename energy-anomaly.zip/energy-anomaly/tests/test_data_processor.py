import numpy as np
import pandas as pd
import pytest

from src.config import ASSET_IDS, BOUNDS, MIN_PER_DAY
from src.data_processor import SchemaError, add_features, clean, validate_schema
from src.generate_data import generate


def _minute_frame(n=60, asset="Chiller-01", status="RUNNING"):
    t = pd.date_range("2026-10-01", periods=n, freq="1min", tz="UTC")
    return pd.DataFrame({"timestamp": t.strftime("%Y-%m-%dT%H:%M:%SZ"), "asset_id": asset,
                         "power_kw": 200.0 + np.arange(n) * 0.1, "flow_rate": 450.0,
                         "supply_temp_c": 7.0 + np.arange(n) * 0.01, "return_temp_c": 12.0 + np.arange(n) * 0.01,
                         "pressure_bar": 4.2, "status": status})


# ---------------------------------------------------------------- generator
def test_generator_injects_every_dirty_data_type(dataset):
    raw, labels = dataset["raw"], dataset["labels"]
    assert {"sensor_freeze", "power_surge", "efficiency_drift", "physical_outlier",
            "comm_dropout_missing", "comm_dropout_nan"} <= set(labels["anomaly_type"])
    assert (raw["power_kw"] < 0).any()
    assert (raw["supply_temp_c"] > 900).any() or (raw["return_temp_c"] > 900).any()
    assert raw[["power_kw", "flow_rate"]].isna().any().any()
    assert (raw.groupby("asset_id").size() < 7 * MIN_PER_DAY).all()      # rows deleted by the dropout


def test_generator_rejects_span_shorter_than_schedule():
    with pytest.raises(ValueError):
        generate(1, 3)


def test_drift_is_25pct_class_rise_over_48h(dataset):
    d = dataset["labels"].query("anomaly_type == 'efficiency_drift'")
    assert len(d) == 2 and d["ramp_hours"].eq(48).all() and d["rise"].between(0.20, 0.30).all()


# ---------------------------------------------------------------- cleaning
def test_clean_restores_complete_grid(dataset):
    df = dataset["clean"]
    assert (df.groupby("asset_id").size() == 7 * MIN_PER_DAY).all()          # 10,080 rows per machine
    assert set(df["asset_id"]) == set(ASSET_IDS)
    assert dataset["report"]["missing_timestamps_restored"] > 0
    assert df["timestamp"].is_monotonic_increasing or df.groupby("asset_id")["timestamp"].apply(
        lambda s: s.is_monotonic_increasing).all()


def test_physical_bounds_enforced_and_gaps_filled(dataset):
    df = dataset["clean"]
    assert dataset["report"]["bound_violations"] > 0
    assert df["bound_violation"].sum() == dataset["report"]["bound_violations"]
    for col, (lo, hi) in BOUNDS.items():
        if lo is not None:
            assert (df[col] >= lo).all()
        if hi is not None:
            assert (df[col] <= hi).all()
    assert not df["data_gap"].any()                                          # all gaps <= 30 min got filled


def test_frozen_sensor_flagged_only_while_running(dataset):
    df, labels = dataset["clean"], dataset["labels"]
    assert not (df["sensor_frozen"] & (df["status"] != "RUNNING")).any()
    for r in labels.query("anomaly_type == 'sensor_freeze'").itertuples():
        win = df[(df["asset_id"] == r.asset_id) & df["timestamp"].between(pd.Timestamp(r.start), pd.Timestamp(r.end))]
        assert win["sensor_frozen"].mean() > 0.95


def test_no_false_freeze_on_healthy_noise():
    raw = _minute_frame(120)
    raw["return_temp_c"] += np.random.default_rng(0).normal(0, 0.05, len(raw))
    df, _ = clean(raw)
    assert not df["sensor_frozen"].any()


def test_domain_features():
    df = add_features(clean(_minute_frame(90))[0])
    r = df.iloc[70]
    assert r["delta_t"] == pytest.approx(r["return_temp_c"] - r["supply_temp_c"])
    assert r["specific_energy"] == pytest.approx(r["power_kw"] / (r["flow_rate"] + 1e-5))
    assert r["load_ratio"] == pytest.approx(r["power_kw"] / 350.0)
    assert df["rolling_power_mean_1h"].iloc[-1] == pytest.approx(df["power_kw"].iloc[-60:].mean())


# ---------------------------------------------------------------- robustness of the input contract
def test_short_gap_is_interpolated_and_flagged():
    raw = _minute_frame(60).drop(index=range(20, 30))
    df, rep = clean(raw)
    assert len(df) == 60 and rep["missing_timestamps_restored"] == 10
    assert df["was_missing"].sum() == 10 and not df["power_kw"].isna().any()
    assert df.loc[25, "power_kw"] == pytest.approx(200.0 + 25 * 0.1, abs=0.05)


def test_invalid_status_does_not_crash_and_is_reported():
    raw = _minute_frame(40)
    raw["status"] = raw["status"].astype(object)
    raw.loc[5:8, "status"] = ["garbage", None, "running ", 7]
    df, rep = clean(raw)
    assert len(df) == 40
    assert set(df["status"].unique()) <= {"RUNNING", "STANDBY", "OFF", "UNKNOWN"}
    assert df.loc[7, "status"] == "RUNNING"                                  # normalised, not discarded


def test_timestamps_with_seconds_are_snapped_to_the_minute():
    raw = _minute_frame(30)
    raw["timestamp"] = pd.to_datetime(raw["timestamp"]) + pd.Timedelta(seconds=17)
    raw["timestamp"] = raw["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    df, rep = clean(raw)
    assert len(df) == 30 and rep["missing_timestamps_restored"] == 0 and not df["power_kw"].isna().any()


def test_coarse_cadence_is_rejected_instead_of_fabricated():
    raw = _minute_frame(120).iloc[::5]
    with pytest.raises(SchemaError):
        clean(raw)


def test_missing_columns_raise_schema_error():
    with pytest.raises(SchemaError):
        validate_schema(_minute_frame(10).drop(columns=["pressure_bar"]))


def test_unknown_assets_are_dropped_and_reported():
    raw = pd.concat([_minute_frame(10), _minute_frame(10, asset="Boiler-99")])
    df, rep = clean(raw)
    assert set(df["asset_id"]) == {"Chiller-01"} and rep["unknown_assets_dropped"] == ["Boiler-99"]


def test_all_unknown_assets_yields_empty_frame_not_a_crash():
    df, rep = clean(_minute_frame(10, asset="Boiler-99"))
    assert df.empty and rep["unknown_assets_dropped"] == ["Boiler-99"]
