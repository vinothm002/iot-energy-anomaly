import pandas as pd
import pytest

from src.config import SEED
from src.data_processor import clean
from src.generate_data import generate
from src.train import fit


@pytest.fixture(scope="session")
def dataset():
    raw, labels = generate(SEED, 7)
    cleaned, report = clean(raw)
    return {"raw": raw, "labels": labels, "clean": cleaned, "report": report}


@pytest.fixture(scope="session")
def detector(dataset):
    return fit(dataset["clean"], verbose=False)


@pytest.fixture(scope="session")
def scored(dataset, detector):
    return detector.score(dataset["clean"])


def reading_from(df: pd.DataFrame, asset: str, when: str) -> dict:
    """A telemetry reading (API payload) taken from the cleaned frame."""
    r = df[(df["asset_id"] == asset) & (df["timestamp"] == pd.Timestamp(when, tz="UTC"))].iloc[0]
    return {"timestamp": f"{when}Z" if not when.endswith("Z") else when, "asset_id": asset,
            "power_kw": float(r["power_kw"]), "flow_rate": float(r["flow_rate"]),
            "supply_temp_c": float(r["supply_temp_c"]), "return_temp_c": float(r["return_temp_c"]),
            "pressure_bar": float(r["pressure_bar"]), "status": r["status"]}
