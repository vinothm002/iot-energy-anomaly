import numpy as np
import pandas as pd
import pytest

from src.config import ASSETS, CRITICAL_THRESHOLD, TRAIN_DAYS, WARNING_THRESHOLD
from src.detector import AnomalyDetector, classify
from src.generate_data import FAULTS, MIN_PER_DAY
from src.insights import audit
from src.train import training_mask


def test_classification_boundaries():
    assert classify(0.4999) == "NORMAL" and classify(0.50) == "WARNING"
    assert classify(0.7499) == "WARNING" and classify(0.75) == "CRITICAL"
    assert list(classify(np.array([0.1, 0.6, 0.9]))) == ["NORMAL", "WARNING", "CRITICAL"]


def test_training_uses_only_healthy_running_reference_window(dataset):
    df = dataset["clean"]
    m = training_mask(df)
    t = df[m]
    assert (t["status"] == "RUNNING").all()
    assert t["timestamp"].max() < df["timestamp"].min() + pd.Timedelta(days=TRAIN_DAYS)
    assert not t["sensor_frozen"].any() and not t["bound_violation"].any() and not t["was_imputed"].any()


def test_scores_are_bounded_and_consistent(scored):
    assert scored["anomaly_score"].between(0, 1).all()
    assert (scored["classification"] == classify(scored["anomaly_score"].to_numpy())).all()
    assert (scored.loc[scored["status"] != "RUNNING", "perf_score"] == 0).all()   # standby/off never anomalous


def test_standby_and_off_periods_are_not_false_alarms(scored):
    quiet = scored[(scored["status"] != "RUNNING") & ~scored["bound_violation"]]
    assert quiet["alarm"].mean() < 0.01


def test_every_injected_surge_and_freeze_raises_an_alarm(dataset, scored):
    for r in dataset["labels"].query("anomaly_type in ['power_surge', 'sensor_freeze']").itertuples():
        win = scored[(scored["asset_id"] == r.asset_id)
                     & scored["timestamp"].between(pd.Timestamp(r.start), pd.Timestamp(r.end))]
        assert win["alarm"].mean() > 0.8, (r.asset_id, r.anomaly_type)


def test_surge_diagnosis_matches_spec_wording(dataset, scored):
    r = dataset["labels"].query("anomaly_type == 'power_surge' and asset_id == 'Chiller-01'").iloc[0]
    win = scored[(scored["asset_id"] == "Chiller-01")
                 & scored["timestamp"].between(pd.Timestamp(r["start"]) + pd.Timedelta(minutes=5), pd.Timestamp(r["end"]))]
    assert (win["diagnosis_code"] == "POWER_SURGE").mean() > 0.9
    assert win["diagnosis"].iloc[0].startswith("High power surge detected without proportional flow increase")


def test_baseline_is_clamped_outside_trained_flow_range(detector):
    m = detector.assets["Chiller-01"]
    far = detector.baseline_kw("Chiller-01", np.array([0.0, 6000.0]))
    edge = detector.baseline_kw("Chiller-01", np.array([m.flow_min * 0.9, m.flow_max * 1.1]))
    assert np.allclose(far, edge) and np.isfinite(far).all()


def test_model_roundtrip(detector, tmp_path, dataset):
    p = tmp_path / "m.joblib"
    detector.save(p)
    loaded = AnomalyDetector.load(p)
    sample = dataset["clean"].iloc[3000:3400].reset_index(drop=True)
    sample = sample[sample["asset_id"] == sample["asset_id"].iloc[0]].reset_index(drop=True)
    a = detector.score(sample, with_history=False)["anomaly_score"].to_numpy()
    b = loaded.score(sample, with_history=False)["anomaly_score"].to_numpy()
    assert np.allclose(a, b)


def test_load_rejects_incompatible_file(tmp_path):
    import joblib
    joblib.dump({"features": ["x"], "assets": {}}, tmp_path / "bad.joblib")
    with pytest.raises(ValueError):
        AnomalyDetector.load(tmp_path / "bad.joblib")


# ---------------------------------------------------------------- insights
def test_drift_energy_matches_injected_ground_truth(scored):
    """Retroactive costing should recover the injected waste to within 10%."""
    summary = audit(scored)
    for asset, kind, start, _, p in FAULTS:
        if kind != "efficiency_drift":
            continue
        g = scored[scored["asset_id"] == asset].reset_index(drop=True)
        m = np.arange(len(g))
        f = 1 + p["rise"] * np.clip((m - start) / (p["ramp_hours"] * 60), 0, 1) * (m >= start)
        truth = (g["power_kw"].to_numpy() * (1 - 1 / f))[(g["status"] == "RUNNING").to_numpy()].sum() / 60
        est = sum(e["excess_kwh"] for e in summary["flagged_intervals"]
                  if e["asset_id"] == asset and e["root_cause"] == "EFFICIENCY_DRIFT")
        assert est == pytest.approx(truth, rel=0.10), asset


def test_events_use_wall_clock_duration_and_cost_matches_tariff(scored):
    summary = audit(scored)
    for e in summary["flagged_intervals"]:
        span = (pd.Timestamp(e["end"]) - pd.Timestamp(e["start"])).total_seconds() / 60 + 1
        assert e["duration_min"] == span
        assert e["cost_usd"] == pytest.approx(e["excess_kwh"] * 0.12, abs=0.011)
    assert summary["estimated_cost_usd"] == pytest.approx(summary["excess_energy_kwh"] * 0.12, abs=0.01)
    assert summary["anomaly_events"] == len(summary["flagged_intervals"])


def test_surge_during_a_frozen_sensor_is_still_costed(dataset, detector):
    """Freeze flags only affect temperature probes; power/flow stay valid for energy accounting."""
    df = dataset["clean"].copy()
    win = ((df["asset_id"] == "Chiller-01") & (df["timestamp"] >= "2026-10-06 10:10:00+00:00")
           & (df["timestamp"] < "2026-10-06 10:30:00+00:00"))
    assert df.loc[win & (df["timestamp"] < "2026-10-06 10:50:00+00:00"), "sensor_frozen"].all()
    df.loc[win, "power_kw"] *= 1.5
    summary = audit(detector.score(df))
    hits = [e for e in summary["flagged_intervals"]
            if e["asset_id"] == "Chiller-01" and e["category"] == "performance"
            and e["start"] <= "2026-10-06T10:30:00Z" and e["end"] >= "2026-10-06T10:10:00Z"]
    assert hits and sum(e["excess_kwh"] for e in hits) > 20
