"""Task 1.3/1.4 - cleaning, sanity validation and domain feature engineering.

    python -m src.data_processor      # data/raw_telemetry.csv -> data/cleaned_telemetry.csv

`clean()` is shared by training and the API so both see identical preprocessing.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from src.config import (ASSET_IDS, ASSETS, BOUNDS, CLEAN_PATH, DATA_DIR, FREEZE_WINDOW, FREQ,
                        MAX_INTERPOLATE_GAP, NUMERIC_COLUMNS, RAW_COLUMNS, RAW_PATH, SCORED_PATH,
                        STATUSES, TEMP_COLUMNS)


class SchemaError(ValueError):
    """Raised when input telemetry is unusable (missing columns, wrong cadence)."""


def load_raw(path=None) -> pd.DataFrame:
    return pd.read_csv(path or RAW_PATH)


def _norm_status(v):
    if isinstance(v, str):
        v = v.strip().upper()
        if v in STATUSES:
            return v
    return np.nan


def validate_schema(df: pd.DataFrame) -> pd.DataFrame:
    """Check columns, parse types, snap timestamps to the minute grid, drop duplicates.

    Invalid status values become NaN (not a string dtype / pd.NA) so later boolean masks are NA-safe.
    """
    missing = set(RAW_COLUMNS) - set(df.columns)
    if missing:
        raise SchemaError(f"missing columns: {sorted(missing)}")
    out = df[RAW_COLUMNS].copy()
    out["timestamp"] = pd.to_datetime(out["timestamp"], utc=True, errors="coerce").dt.floor(FREQ)
    out = out.dropna(subset=["timestamp", "asset_id"])
    for col in NUMERIC_COLUMNS:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out["status"] = out["status"].map(_norm_status).astype(object)
    out["asset_id"] = out["asset_id"].astype(object)
    out = out.sort_values(["asset_id", "timestamp"]).drop_duplicates(["asset_id", "timestamp"], keep="last")

    for asset, g in out.groupby("asset_id"):
        if len(g) >= 3 and g["timestamp"].diff().median() > pd.Timedelta(minutes=1.5):
            raise SchemaError(f"{asset}: expected 1-minute readings, found a coarser cadence "
                              "(re-sampling would fabricate data)")
    return out.reset_index(drop=True)


def reindex_to_grid(df: pd.DataFrame, freq: str = FREQ) -> pd.DataFrame:
    """Restore missing timestamps so every asset has a complete 1-minute grid."""
    parts = []
    for asset, g in df.groupby("asset_id", sort=False):
        g = g.set_index("timestamp")
        full = pd.date_range(g.index.min(), g.index.max(), freq=freq)
        g = g.reindex(full)
        g.index.name = "timestamp"
        g["was_missing"] = g["asset_id"].isna()
        g["asset_id"] = asset
        parts.append(g.reset_index())
    return pd.concat(parts, ignore_index=True)


def apply_physical_bounds(df: pd.DataFrame) -> pd.DataFrame:
    """Impossible values (negative power, 999 C ...) -> NaN, with a bound_violation flag."""
    out = df.copy()
    violation = pd.Series(False, index=out.index)
    for col, (lo, hi) in BOUNDS.items():
        bad = pd.Series(False, index=out.index)
        if lo is not None:
            bad |= out[col] < lo
        if hi is not None:
            bad |= out[col] > hi
        out.loc[bad, col] = np.nan
        violation |= bad
    out["bound_violation"] = violation
    return out


def _spread_back(window_end_flags: np.ndarray, window: int) -> np.ndarray:
    """A flag at the END of a frozen window marks the whole window."""
    s = pd.Series(window_end_flags.astype(int))
    return s[::-1].rolling(window, min_periods=1).max()[::-1].to_numpy().astype(bool)


def flag_frozen(df: pd.DataFrame, window: int = FREEZE_WINDOW) -> pd.DataFrame:
    """Flag temperature sensors stuck on one value: rolling(window).std() == 0 while RUNNING."""
    out = df.copy()
    running = out["status"].eq("RUNNING").to_numpy()
    frozen_any = np.zeros(len(out), dtype=bool)
    for col in TEMP_COLUMNS:
        flag = np.zeros(len(out), dtype=bool)
        for _, idx in out.groupby("asset_id", sort=False).indices.items():
            std = out[col].iloc[idx].rolling(window, min_periods=window).std()
            flag[idx] = _spread_back((std < 1e-6).to_numpy(), window)
        flag &= running
        out[f"{col}_frozen"] = flag
        frozen_any |= flag
    out["sensor_frozen"] = frozen_any
    return out


def impute(df: pd.DataFrame, max_gap: int = MAX_INTERPOLATE_GAP) -> pd.DataFrame:
    """Time interpolation for gaps <= max_gap minutes; longer gaps stay NaN and set data_gap."""
    out = df.copy()
    out["was_imputed"] = out[NUMERIC_COLUMNS].isna().any(axis=1)
    parts = []
    for _, g in out.groupby("asset_id", sort=False):
        g = g.set_index("timestamp")
        for col in NUMERIC_COLUMNS:
            s = g[col]
            na = s.isna()
            run_len = na.groupby((~na).cumsum()).transform("sum")
            too_long = na & (run_len > max_gap)
            g[col] = s.interpolate(method="time", limit_area="inside").ffill().bfill().mask(too_long)
        g["status"] = g["status"].ffill(limit=max_gap).bfill(limit=max_gap).fillna("UNKNOWN")
        parts.append(g.reset_index())
    out = pd.concat(parts, ignore_index=True)
    out["data_gap"] = out[NUMERIC_COLUMNS].isna().any(axis=1)
    return out


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["delta_t"] = out["return_temp_c"] - out["supply_temp_c"]
    out["specific_energy"] = out["power_kw"] / (out["flow_rate"] + 1e-5)
    out["rolling_power_mean_1h"] = (
        out.set_index("timestamp").groupby("asset_id", sort=False)["power_kw"]
        .transform(lambda s: s.rolling("60min", min_periods=1).mean()).to_numpy())
    rated = out["asset_id"].map({a: s["rated_kw"] for a, s in ASSETS.items()})
    out["load_ratio"] = out["power_kw"] / rated
    return out


def clean(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Full cleaning + feature pipeline. Returns (cleaned frame, data-quality report)."""
    df = validate_schema(raw)
    unknown = sorted(set(df["asset_id"]) - set(ASSET_IDS))
    df = df[df["asset_id"].isin(ASSET_IDS)]
    input_rows = len(df)
    if df.empty:                                  # nothing usable: callers turn this into a 422
        return df.reset_index(drop=True), {"input_rows": 0, "output_rows": 0, "unknown_assets_dropped": unknown}
    df = reindex_to_grid(df)
    nan_cells_before = int(df[NUMERIC_COLUMNS].isna().sum().sum())
    df = apply_physical_bounds(df)
    df = flag_frozen(df)
    df = impute(df)
    df = add_features(df)
    df = df.sort_values(["asset_id", "timestamp"]).reset_index(drop=True)
    report = {
        "input_rows": input_rows,
        "output_rows": len(df),
        "missing_timestamps_restored": int(df["was_missing"].sum()),
        "nan_cells_before_bounds": nan_cells_before,
        "bound_violations": int(df["bound_violation"].sum()),
        "frozen_sensor_minutes": int(df["sensor_frozen"].sum()),
        "rows_imputed": int(df["was_imputed"].sum()),
        "rows_with_unfillable_gap": int(df["data_gap"].sum()),
        "unknown_status_rows": int((df["status"] == "UNKNOWN").sum()),
        "unknown_assets_dropped": unknown,
    }
    return df, report


def save_clean(df: pd.DataFrame, path=None) -> None:
    out = df.copy()
    out["timestamp"] = out["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    out.to_csv(path or CLEAN_PATH, index=False)


def load_clean(path=None) -> pd.DataFrame:
    df = pd.read_csv(path or CLEAN_PATH)
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    return df


def save_scored(df: pd.DataFrame) -> None:
    out = df.copy()
    out["timestamp"] = out["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    out.to_csv(SCORED_PATH, index=False)


def load_scored() -> pd.DataFrame:
    df = pd.read_csv(SCORED_PATH)
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    return df


def main(argv=None) -> None:
    df, report = clean(load_raw())
    save_clean(df)
    print(f"Cleaned telemetry -> {CLEAN_PATH}")
    for key, value in report.items():
        print(f"  {key:30s} {value}")


if __name__ == "__main__":
    main()
