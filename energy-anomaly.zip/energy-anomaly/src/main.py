"""Task 4 - FastAPI service.

    uvicorn src.main:app --port 8000        # or ./run.sh

    GET  /                    dashboard (results, charts, CSV upload)
    GET  /health              model loaded?
    POST /api/v1/diagnose     one reading -> score, class, root cause
    POST /api/v1/batch-audit  CSV upload (multipart field "file") or JSON array -> events, kWh, $
    GET  /docs                Swagger UI
"""
from __future__ import annotations

import logging
import math
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Literal

import pandas as pd
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field, TypeAdapter, ValidationError, field_validator

from src.config import CRITICAL_THRESHOLD, MODEL_PATH, OUTPUTS_DIR, WARNING_THRESHOLD
from src.dashboard import build_report_html
from src.detector import AnomalyDetector
from src.service import ServiceError, batch_audit_frame, diagnose_reading, parse_csv

log = logging.getLogger("energy-api")


class Reading(BaseModel):
    """One telemetry reading. Impossible values (negative power, 999 C) are accepted on purpose and
    diagnosed as data-quality findings; NaN/inf are rejected."""

    timestamp: datetime
    asset_id: Literal["Chiller-01", "Compressor-02", "Pump-03"]
    power_kw: float
    flow_rate: float
    supply_temp_c: float
    return_temp_c: float
    pressure_bar: float
    status: Literal["RUNNING", "STANDBY", "OFF"]

    @field_validator("power_kw", "flow_rate", "supply_temp_c", "return_temp_c", "pressure_bar")
    @classmethod
    def finite(cls, v: float) -> float:
        if not math.isfinite(v):
            raise ValueError("must be a finite number")
        return v

    model_config = {"json_schema_extra": {"example": {
        "timestamp": "2026-10-01T14:30:00Z", "asset_id": "Chiller-01", "power_kw": 285.5,
        "flow_rate": 450.0, "supply_temp_c": 7.2, "return_temp_c": 12.8, "pressure_bar": 4.2,
        "status": "RUNNING"}}}


class BatchReading(BaseModel):
    """Lenient batch row: nulls (communication dropouts) and unknown labels are allowed, exactly
    like the CSV path - the cleaning pipeline reports and repairs them."""

    timestamp: datetime
    asset_id: str
    power_kw: float | None = None
    flow_rate: float | None = None
    supply_temp_c: float | None = None
    return_temp_c: float | None = None
    pressure_bar: float | None = None
    status: str | None = None


class DiagnoseResponse(BaseModel):
    asset_id: str
    timestamp: str
    anomaly_score: float = Field(ge=0, le=1)
    classification: Literal["NORMAL", "WARNING", "CRITICAL"]
    diagnosis_code: str
    diagnosis: str
    baseline_kw: float | None
    power_residual_pct: float | None
    excess_kw: float | None
    features: dict
    note: str


BATCH = TypeAdapter(list[BatchReading])


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        app.state.detector = AnomalyDetector.load(MODEL_PATH)
        log.info("model loaded from %s", MODEL_PATH)
    except Exception as exc:        # missing or incompatible model file
        app.state.detector = None
        log.warning("model not usable (%s) - run `python -m src.train`", exc)
    yield


app = FastAPI(title="Industrial Asset Energy & Anomaly API", version="3.0.0", lifespan=lifespan)


def _detector(request: Request) -> AnomalyDetector:
    det = getattr(request.app.state, "detector", None)
    if det is None:
        raise HTTPException(503, "model not loaded; run `python -m src.train` and restart")
    return det


@app.exception_handler(ServiceError)
async def _service_error(_request: Request, exc: ServiceError):
    return JSONResponse(status_code=exc.status, content={"detail": exc.detail})


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def dashboard():
    return build_report_html(OUTPUTS_DIR)


@app.get("/health")
def health(request: Request):
    det = getattr(request.app.state, "detector", None)
    if det is None:
        raise HTTPException(503, detail={"status": "unavailable", "model_loaded": False})
    return {"status": "ok", "model_loaded": True, "assets": sorted(det.assets),
            "trained_at": det.meta.get("trained_at"),
            "thresholds": {"warning": WARNING_THRESHOLD, "critical": CRITICAL_THRESHOLD}}


@app.post("/api/v1/diagnose", response_model=DiagnoseResponse)
def diagnose(reading: Reading, request: Request):
    return diagnose_reading(_detector(request), reading.model_dump())


@app.post("/api/v1/batch-audit")
async def batch_audit(request: Request, report: bool = Query(False, description="include shift-handoff text")):
    det = _detector(request)
    ctype = request.headers.get("content-type", "")
    if ctype.startswith("multipart/form-data"):
        upload = (await request.form()).get("file")
        if upload is None or not hasattr(upload, "read"):
            raise HTTPException(422, "multipart upload must include a CSV in field 'file'")
        raw = parse_csv(await upload.read())
    elif ctype.startswith("application/json"):
        body = await request.json()
        if isinstance(body, dict):
            body = body.get("readings", [])
        try:
            rows = BATCH.validate_python(body)
        except ValidationError as exc:
            raise HTTPException(422, exc.errors(include_url=False, include_context=False, include_input=False)) from exc
        raw = pd.DataFrame([r.model_dump() for r in rows])
        if len(raw):
            raw["timestamp"] = raw["timestamp"].astype(str)
    else:
        raise HTTPException(415, "send multipart/form-data (CSV file) or application/json")

    # CPU-bound pandas work (and the optional blocking LLM call) must not stall the event loop
    summary = await run_in_threadpool(batch_audit_frame, det, raw, report)
    log.info("batch-audit rows=%s events=%s excess_kwh=%s", summary["total_records"],
             summary["anomaly_events"], summary["excess_energy_kwh"])
    return summary
