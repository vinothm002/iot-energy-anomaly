"""Self-contained results page, served at "/" and writable as outputs/report.html.

    python -m src.dashboard
"""
from __future__ import annotations

import base64
import json
from pathlib import Path

from src.config import OUTPUTS_DIR

CHART_FILES = [("Power & flow trends", "trends.png"), ("Detected anomalies", "anomalies_detected.png"),
               ("Efficiency drift", "drift_residual.png"), ("Power vs flow", "efficiency_correlation.png"),
               ("Threshold trade-off", "precision_recall.png")]

PAGE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Asset Energy &amp; Anomaly Report</title>
<style>
:root{color-scheme:light;--bg:#f6f6f4;--card:#fff;--ink:#111;--mut:#6b6a66;--line:#e3e2dc;--acc:#2a78d6;--crit:#d03b3b;--warn:#b57a00;--head:#1f3a5f}
@media (prefers-color-scheme:dark){:root{color-scheme:dark;--bg:#14161a;--card:#1d2026;--ink:#ececea;--mut:#9a9992;--line:#30343b;--acc:#5aa0f0;--crit:#f06a6a;--warn:#e3a82a;--head:#0f2038}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 "Segoe UI",system-ui,Arial,sans-serif}
header{background:var(--head);color:#fff;padding:18px 24px}header h1{margin:0;font-size:20px}header p{margin:4px 0 0;opacity:.8;font-size:13px}
main{max-width:1280px;margin:auto;padding:20px}h2{font-size:16px;margin:28px 0 10px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px 14px}.card span{color:var(--mut);font-size:12px}.card b{display:block;font-size:22px;margin-top:2px}
.scroll{overflow-x:auto;background:var(--card);border:1px solid var(--line);border-radius:8px}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:7px 10px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}th{color:var(--mut);font-weight:600}td.wrap{white-space:normal;min-width:260px}
td.n,th.n{text-align:right}.CRITICAL{color:var(--crit);font-weight:600}.WARNING{color:var(--warn);font-weight:600}
.tabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}button,select,input[type=file]{background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:7px 12px;font:inherit;cursor:pointer}
.tabs button.on,#go{background:var(--acc);color:#fff;border-color:var(--acc)}
.chart{background:#fcfcfb;border:1px solid var(--line);border-radius:8px;padding:6px;overflow-x:auto;color:#555}.chart img{max-width:100%;display:block;margin:auto}
pre{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:14px;white-space:pre-wrap;margin:0;font:13px/1.5 Consolas,monospace}
.bar{display:flex;gap:10px;margin-bottom:10px;flex-wrap:wrap;align-items:center}small{color:var(--mut)}.empty{color:var(--mut);padding:12px}
</style></head><body>
<header><h1>Industrial Asset Energy &amp; Anomaly Report</h1><p id="sub"></p></header>
<main>
<div class="bar" id="uploadbar"><input type="file" id="file" accept=".csv"><button id="go">Analyze CSV</button><small id="status">Upload a telemetry CSV (e.g. data/raw_telemetry.csv) to re-run the audit.</small></div>
<div class="grid" id="kpi"></div>
<h2>Per asset</h2><div class="scroll"><table id="assets"></table></div>
<h2>Charts</h2><div class="tabs" id="tabs"></div><div class="chart" id="chartbox"></div>
<div id="evalsec">
<h2>Detection quality - temporal hold-out</h2><div class="scroll"><table id="types"></table></div>
<h2>Detection quality - fresh unseen dataset</h2><div class="scroll"><table id="fresh"></table></div>
<h2>Efficiency drift detection (hold-out)</h2><div class="scroll"><table id="drift"></table></div>
<h2>Ablation: ML vs physics vs hybrid</h2><div class="scroll"><table id="abl"></table></div>
<h2>Alarm threshold sweep (hold-out)</h2><div class="scroll"><table id="sweep"></table></div>
</div>
<div id="evalnote" class="empty" style="display:none">Evaluation tables apply to the generated training dataset only and are hidden for uploaded files (an upload has no injected-fault labels).</div>
<h2>Shift handoff</h2><pre id="handoff"></pre>
<h2>Flagged intervals</h2>
<div class="bar"><select id="cat"><option value="">All categories</option><option value="performance">Performance</option><option value="data_quality">Data quality</option></select>
<select id="sev"><option value="">All severities</option><option>CRITICAL</option><option>WARNING</option></select>
<select id="asset"><option value="">All assets</option></select><small id="count"></small></div>
<div class="scroll"><table id="rows"></table></div>
</main>
<script>
const D=__DATA__;let A=D.audit,E=D.eval,H=D.handoff;
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const f=(x,n=1)=>(x==null||isNaN(x))?"–":Number(x).toLocaleString(undefined,{maximumFractionDigits:n});
const pct=x=>x==null?"–":(x*100).toFixed(1)+"%";
const plus=x=>x==null?"–":"+"+x+"%";
const tbl=(h,rows)=>"<tr>"+h.map((x,i)=>`<th class="${i>=1?"n":""}">${x}</th>`).join("")+"</tr>"+rows.map(r=>"<tr>"+r.map((c,i)=>`<td class="${i>=1?"n":""}">${c}</td>`).join("")+"</tr>").join("");
const names={power_surge:"Power surge",sensor_freeze:"Frozen sensor",efficiency_drift:"Efficiency drift",physical_outlier:"Physical outlier (rule)"};
const typeTable=r=>tbl(["Injected fault","Events","Detected","Event recall","Minute recall","Median delay (min)"],Object.entries(r.per_type).map(([k,d])=>[names[k]||k,d.events,d.detected,pct(d.event_recall),pct(d.minute_recall),f(d.median_delay_min,0)]));
function render(){
  const H0=E&&E.temporal_holdout,F0=E&&E.fresh_seed,k=[];
  if(A){k.push(["Records analysed",f(A.total_records,0)],["Records in alarm",f(A.anomalous_records,0)],["Critical / Warning (alarm)",f(A.critical_alarm_records,0)+" / "+f(A.warning_alarm_records,0)],["Alarm episodes",A.anomaly_events],["Performance events",A.performance_events],["Data-quality events",A.data_quality_events],["Excess energy",f(A.excess_energy_kwh)+" kWh"],["Estimated cost","$"+f(A.estimated_cost_usd,2)])}
  if(H0){k.push(["Precision (hold-out)",pct(H0.precision)],["Event recall (hold-out)",pct(H0.macro_event_recall)],["False alarms / asset-day",f(H0.false_alarms_per_asset_day,2)])}
  if(F0){k.push(["Precision (fresh seed)",pct(F0.precision)],["False alarms (fresh seed)",f(F0.false_alarms_per_asset_day,2)])}
  $("kpi").innerHTML=k.length?k.map(x=>`<div class="card"><span>${x[0]}</span><b>${x[1]}</b></div>`).join(""):"<div class='empty'>No results yet. Run: ./run.sh pipeline</div>";
  $("sub").textContent=A?`${f(A.total_records,0)} records · tariff $${A.tariff_usd_per_kwh}/kWh · ${A.flagged_intervals.length} flagged intervals`:"";
  $("assets").innerHTML=A?tbl(["Asset","Events","Excess kWh","Cost USD"],Object.entries(A.by_asset).map(([k,v])=>[esc(k),v.events,f(v.excess_kwh,2),"$"+f(v.cost_usd,2)])):"";
  $("evalsec").style.display=H0?"":"none";$("evalnote").style.display=(!H0&&A)?"":"none";
  if(H0){
    $("types").innerHTML=typeTable(H0);$("fresh").innerHTML=F0?typeTable(F0):"";
    $("drift").innerHTML=tbl(["Asset","First alarm (h)","Rise then","Sustained (h)","Rise then","Diagnosis (h)","Rise then"],H0.drift_detection.map(d=>[d.asset_id,f(d.first_alarm_hours),plus(d.injected_rise_at_alarm_pct),f(d.sustained_alarm_hours),plus(d.injected_rise_at_sustained_pct),f(d.first_drift_diagnosis_hours),plus(d.injected_rise_at_diagnosis_pct)]));
    $("abl").innerHTML=tbl(["Variant","Precision","Event recall","Minute recall","False alarms / asset-day"],Object.entries(H0.ablation).map(([n,a])=>[n,pct(a.precision),pct(a.macro_event_recall),pct(a.macro_minute_recall),a.false_alarms_per_asset_day]));
    $("sweep").innerHTML=tbl(["Threshold","Precision","Minute recall","Event recall","False alarms / asset-day"],H0.threshold_sweep.map(s=>[s.threshold.toFixed(2)+(Math.abs(s.threshold-H0.operating_threshold)<1e-9?" ★":""),pct(s.precision),pct(s.macro_minute_recall),pct(s.macro_event_recall),s.false_alarms_per_asset_day]));
  }
  $("handoff").textContent=H||"(no shift handoff yet)";
  const sel=$("asset"),cur=sel.value;sel.length=1;if(A)Object.keys(A.by_asset).forEach(a=>sel.add(new Option(a,a)));sel.value=cur;
  rows();
}
function rows(){
  if(!A){$("rows").innerHTML="";$("count").textContent="";return}
  const c=$("cat").value,s=$("sev").value,a=$("asset").value;
  const r=A.flagged_intervals.filter(i=>(!c||i.category===c)&&(!s||i.severity===s)&&(!a||i.asset_id===a)).sort((x,y)=>y.excess_kwh-x.excess_kwh||x.start.localeCompare(y.start));
  $("count").textContent=r.length+" shown, sorted by excess energy";
  const t=v=>v.replace("T"," ").replace("Z","");
  $("rows").innerHTML="<tr><th>Asset</th><th>Start</th><th>End</th><th class='n'>Min</th><th>Severity</th><th>Root cause</th><th class='n'>Excess kWh</th><th>Diagnosis</th></tr>"+
  r.map(i=>`<tr><td>${esc(i.asset_id)}</td><td>${t(i.start)}</td><td>${t(i.end)}</td><td class="n">${i.duration_min}</td><td class="${i.severity}">${i.severity}</td><td>${esc(i.root_cause)}</td><td class="n">${f(i.excess_kwh,2)}</td><td class="wrap">${esc(i.diagnosis)}</td></tr>`).join("");
}
const tabs=$("tabs");
D.charts.forEach((c,i)=>{const b=document.createElement("button");b.textContent=c[0];b.onclick=()=>{[...tabs.children].forEach(x=>x.classList.remove("on"));b.classList.add("on");
  $("chartbox").innerHTML=c[1]?`<img alt="${c[0]}" src="${c[1]}">`:"<div class='empty'>Chart not found. Run: python -m src.visualize</div>"};tabs.appendChild(b);if(!i)b.click()});
["cat","sev","asset"].forEach(id=>$(id).onchange=rows);
$("go").onclick=async()=>{const fl=$("file").files[0];if(!fl){alert("Choose a CSV file first");return}
  $("status").textContent="Analyzing...";const fd=new FormData();fd.append("file",fl);
  try{const r=await fetch("/api/v1/batch-audit?report=true",{method:"POST",body:fd});const j=await r.json();
    if(!r.ok){$("status").textContent="Error: "+(typeof j.detail==="string"?j.detail:JSON.stringify(j.detail));return}
    A=j;H=j.shift_handoff||"";E=null;$("status").textContent="Done - "+f(j.total_records,0)+" records analysed";render()}
  catch(e){$("status").textContent="Failed: "+e}};
if(!/^https?:/.test(location.protocol))$("uploadbar").style.display="none";
render();
</script></body></html>"""


def build_report_html(out_dir: Path | None = None) -> str:
    out_dir = Path(out_dir or OUTPUTS_DIR)

    def read_json(name):
        p = out_dir / name
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None

    def img(name):
        p = out_dir / name
        return "data:image/png;base64," + base64.b64encode(p.read_bytes()).decode() if p.exists() else ""

    handoff = out_dir / "shift_handoff.md"
    data = {"audit": read_json("audit_summary.json"), "eval": read_json("evaluation.json"),
            "handoff": handoff.read_text(encoding="utf-8") if handoff.exists() else "",
            "charts": [[title, img(fn)] for title, fn in CHART_FILES]}
    return PAGE.replace("__DATA__", json.dumps(data).replace("</", "<\\/"))


def main(argv=None) -> None:
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    out = OUTPUTS_DIR / "report.html"
    out.write_text(build_report_html(OUTPUTS_DIR), encoding="utf-8")
    print(f"Report written -> {out}  (double-click to open in your browser)")


if __name__ == "__main__":
    main()
