"""Run the whole pipeline: generate -> clean+train+evaluate -> charts -> insights -> report page.

    python -m src.pipeline
"""
from src import dashboard, generate_data, insights, train, visualize


def main() -> None:
    for title, fn in (("1/5 Generating data", generate_data.main), ("2/5 Cleaning, training, evaluating", train.main),
                      ("3/5 Drawing charts", visualize.main), ("4/5 Building insights", insights.main),
                      ("5/5 Building report page", dashboard.main)):
        print(f"\n===== {title} =====")
        fn([])
    print("\nAll done. Start the service with: ./run.sh   (or open outputs/report.html)")


if __name__ == "__main__":
    main()
