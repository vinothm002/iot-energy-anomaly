"""Hybrid anomaly detector: Isolation Forest + physics baseline residual + drift + hard rules.

Used by training (src/train.py), the insight generator and the API.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from src.config import (ALARM_SMOOTHING, ASSETS, BOUND_VIOLATION_SCORE, CRITICAL_THRESHOLD,
                        DRIFT_RESIDUAL, DRIFT_WINDOW, FREEZE_SCORE, MODEL_FEATURES, MODEL_PATH,
                        SURGE_RESIDUAL, WARNING_THRESHOLD)

SCORE_ANCHORS = [0.0, 0.25, 0.50, 0.75, 1.0]
RESID_Z_ANCHORS = [0.0, 2.0, 4.0, 6.0, 10.0]


def classify(score):
    """Anomaly score -> NORMAL (<0.50) / WARNING (0.50-0.75) / CRITICAL (>=0.75)."""
    s = np.asarray(score, dtype=float)
    out = np.where(s >= CRITICAL_THRESHOLD, "CRITICAL", np.where(s >= WARNING_THRESHOLD, "WARNING", "NORMAL"))
    return out.item() if out.ndim == 0 else out


def calibration_anchors(raw_scores: np.ndarray) -> np.ndarray:
    """Map raw Isolation-Forest scores onto [0, 1] using HELD-OUT healthy data.

    min -> 0, median -> 0.25, then a margin above the worst healthy score seen in the held-out
    window: max + 0.25*span -> 0.50 (WARNING), max + 1*span -> 0.75 (CRITICAL), max + 3*span -> 1.0,
    where span = max - median. So the ML score only raises a WARNING for a minute that is more
    unusual than anything in the healthy calibration data. (An earlier quantile-based mapping,
    99.5th percentile -> 0.50, flagged ~0.5% of healthy minutes by construction and tripled the
    false-alarm rate; see README "Calibration".)
    """
    med, top = float(np.median(raw_scores)), float(raw_scores.max())
    span = max(top - med, 1e-9)
    anchors = np.array([raw_scores.min(), med, top + 0.25 * span, top + 1.0 * span, top + 3.0 * span])
    for i in range(1, len(anchors)):
        anchors[i] = max(anchors[i], anchors[i - 1] + 1e-9)
    return anchors


@dataclass
class AssetModel:
    scaler: object
    model: object
    baseline_coefs: np.ndarray
    anchors: np.ndarray
    flow_min: float
    flow_max: float
    flow_p01: float
    flow_p99: float
    resid_sigma: float = 0.015


ASSET_DRIFT_ACTION = {
    "Chiller-01": "Recommend inspecting heat exchanger tubes for fouling or refrigerant leak.",
    "Compressor-02": "Recommend inspecting compressor seals, intake filter and downstream air leaks.",
    "Pump-03": "Recommend inspecting impeller wear and strainer/heat-exchanger fouling.",
}

MESSAGES = {
    "SENSOR_FREEZE": "Sensor freeze detected on temperature probe. Possible thermocouple failure or communication loop lockup.",
    "DATA_QUALITY": "Sensor reading outside physical limits (e.g. negative power or impossible temperature). Value discarded; check sensor wiring and transmitter.",
    "POWER_SURGE": "High power surge detected without proportional flow increase. Check electrical motor load or compressor stage bypass.",
    "ABNORMAL_OPERATING_POINT": "Operating point outside the learned normal envelope. Review recent setpoint changes and inspect the asset.",
    "NORMAL": "Operating within normal envelope.",
    "NOT_RUNNING": "Asset not running; no performance anomaly assessed.",
}


def drift_message(asset: str, pct: float) -> str:
    return (f"Gradual thermal efficiency loss detected (+{pct * 100:.0f}% above baseline). "
            + ASSET_DRIFT_ACTION.get(asset, "Recommend a performance inspection."))


def _isnan(v) -> bool:
    return v is None or (isinstance(v, float) and math.isnan(v))


def performance_code(row: dict, model: AssetModel | None) -> str:
    """Root cause of a PERFORMANCE anomaly, independent of sensor-quality flags."""
    if row.get("drift_pct", 0) >= DRIFT_RESIDUAL:
        return "EFFICIENCY_DRIFT"
    flow, resid = row.get("flow_rate"), row.get("power_residual_pct")
    flow_normal = (model is None or _isnan(flow)
                   or model.flow_p01 * 0.9 <= flow <= model.flow_p99 * 1.1)
    if not _isnan(resid) and resid >= SURGE_RESIDUAL and flow_normal:
        return "POWER_SURGE"
    if row.get("perf_score", 0) >= WARNING_THRESHOLD:
        return "ABNORMAL_OPERATING_POINT"
    return "NORMAL"


def diagnose_row(row: dict, model: AssetModel | None) -> tuple[str, str]:
    """Returns (diagnosis_code, perf_code). Data-quality findings take display precedence."""
    running = row.get("status") == "RUNNING"
    bound, frozen = bool(row.get("bound_violation")), bool(row.get("sensor_frozen"))
    pcode = performance_code(row, model) if running and not bound else "NORMAL"
    if bound:
        return "DATA_QUALITY", pcode
    if not running:
        return "NOT_RUNNING", pcode
    if frozen:
        return "SENSOR_FREEZE", pcode
    return pcode, pcode


def message_for(code: str, row: dict) -> str:
    if code == "EFFICIENCY_DRIFT":
        return drift_message(row["asset_id"], row.get("drift_pct", 0.0))
    return MESSAGES[code]


def smooth(df: pd.DataFrame, col: str) -> pd.Series:
    """5-minute rolling median per asset (rows must be sorted by asset, timestamp)."""
    return df.groupby("asset_id", sort=False)[col].transform(
        lambda s: s.rolling(ALARM_SMOOTHING, min_periods=1).median())


def _flag(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df:
        return pd.Series(False, index=df.index)
    return df[col].fillna(False).astype(bool)


def _rolling_running_median(df: pd.DataFrame, col: str, window: str) -> pd.Series:
    result = pd.Series(0.0, index=df.index)
    running = df["status"].eq("RUNNING")
    for _, idx in df[running].groupby("asset_id").groups.items():
        s = df.loc[idx].set_index("timestamp")[col]
        result.loc[idx] = s.rolling(window, min_periods=360).median().fillna(0.0).to_numpy()
    return result


class AnomalyDetector:
    def __init__(self, assets: dict[str, AssetModel], meta: dict | None = None):
        self.assets = assets
        self.meta = meta or {}

    # Saved as plain dicts so the file loads however the process was started.
    def save(self, path=None) -> None:
        path = Path(path or MODEL_PATH)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"assets": {a: dict(vars(m)) for a, m in self.assets.items()},
                     "meta": self.meta, "features": MODEL_FEATURES}, path, compress=3)

    @classmethod
    def load(cls, path=None) -> "AnomalyDetector":
        # SECURITY: joblib uses pickle - only load model files you produced yourself.
        bundle = joblib.load(path or MODEL_PATH)
        if not isinstance(bundle, dict) or bundle.get("features") != MODEL_FEATURES:
            raise ValueError("model file is from a different version; run `python -m src.train`")
        return cls({a: AssetModel(**d) for a, d in bundle["assets"].items()}, bundle.get("meta"))

    # -- physics baseline ------------------------------------------------------------------
    def baseline_kw(self, asset: str, flow) -> np.ndarray:
        """Expected healthy power at a flow. Flow is clamped to the trained range (+-10%) so the
        cubic cannot extrapolate to nonsense outside the data it was fitted on."""
        m = self.assets[asset]
        flow = np.clip(np.asarray(flow, dtype=float), m.flow_min * 0.9, m.flow_max * 1.1)
        return np.polyval(m.baseline_coefs, flow / ASSETS[asset]["nominal_flow"])

    def add_baseline(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out["baseline_kw"] = np.nan
        for asset, idx in out.groupby("asset_id").groups.items():
            if asset in self.assets:
                out.loc[idx, "baseline_kw"] = self.baseline_kw(asset, out.loc[idx, "flow_rate"])
        running = out["status"].eq("RUNNING")
        out["power_residual_pct"] = np.where(
            running, (out["power_kw"] - out["baseline_kw"]) / out["baseline_kw"].clip(lower=1e-3), 0.0)
        out.loc[~running, "baseline_kw"] = out.loc[~running, "power_kw"]
        return out

    def ml_score(self, asset: str, X: pd.DataFrame) -> np.ndarray:
        m = self.assets[asset]
        raw = -m.model.score_samples(m.scaler.transform(X[MODEL_FEATURES].to_numpy()))
        return np.interp(raw, m.anchors, SCORE_ANCHORS)

    # -- scoring ---------------------------------------------------------------------------
    def score(self, df: pd.DataFrame, with_history: bool = True) -> pd.DataFrame:
        """`df` must come from data_processor.clean() (sorted by asset, timestamp)."""
        out = self.add_baseline(df)
        running = out["status"].eq("RUNNING")
        frozen, bound = _flag(out, "sensor_frozen"), _flag(out, "bound_violation")
        usable = running & out[MODEL_FEATURES].notna().all(axis=1)

        out["ml_score"] = 0.0
        for asset, idx in out[usable].groupby("asset_id").groups.items():
            if asset in self.assets:
                out.loc[idx, "ml_score"] = self.ml_score(asset, out.loc[idx])
        out.loc[frozen, "ml_score"] = 0.0      # delta_t is corrupted while a probe is frozen

        sigma = out["asset_id"].map({a: m.resid_sigma for a, m in self.assets.items()}).fillna(0.015)
        out["residual_z"] = np.where(running, out["power_residual_pct"] / sigma, 0.0)
        out["residual_score"] = np.interp(out["residual_z"].fillna(0), RESID_Z_ANCHORS, SCORE_ANCHORS)

        out["drift_pct"] = 0.0
        if with_history:
            out["drift_pct"] = _rolling_running_median(out, "power_residual_pct", DRIFT_WINDOW)
        out["drift_score"] = np.interp(out["drift_pct"], [0, DRIFT_RESIDUAL, 0.16, 0.30], [0, 0.5, 0.75, 1.0])

        out["rule_score"] = np.maximum(frozen * FREEZE_SCORE, bound * BOUND_VIOLATION_SCORE)
        # performance score = how wrong the energy/operating point looks; rules = data quality
        out["perf_score"] = out[["ml_score", "residual_score", "drift_score"]].max(axis=1)
        out["anomaly_score"] = out[["perf_score", "rule_score"]].max(axis=1).clip(0, 1).round(4)
        out["classification"] = classify(out["anomaly_score"].to_numpy())
        # ablation scores
        out["score_ml_only"] = out[["ml_score", "rule_score"]].max(axis=1)
        out["score_physics_only"] = out[["residual_score", "drift_score", "rule_score"]].max(axis=1)

        out["alarm"] = (smooth(out, "anomaly_score") >= WARNING_THRESHOLD) | bound
        out["perf_alarm"] = (smooth(out, "perf_score") >= WARNING_THRESHOLD) & running & ~bound

        self._diagnose(out, running, frozen, bound)
        return out

    def _diagnose(self, out, running, frozen, bound) -> None:
        codes = np.where(running, "NORMAL", "NOT_RUNNING").astype(object)
        pcodes = np.full(len(out), "NORMAL", dtype=object)
        texts = np.array([MESSAGES[c] for c in codes], dtype=object)
        resid = out["power_residual_pct"].fillna(0)
        cand = (bound | frozen | (out["perf_score"] >= WARNING_THRESHOLD)
                | (out["drift_pct"] >= DRIFT_RESIDUAL) | (resid >= SURGE_RESIDUAL)).to_numpy()
        pos = np.flatnonzero(cand)
        for p, row in zip(pos, out.iloc[pos].to_dict("records")):
            code, pcode = diagnose_row(row, self.assets.get(row["asset_id"]))
            codes[p], pcodes[p], texts[p] = code, pcode, message_for(code, row)
        out["diagnosis_code"], out["perf_code"], out["diagnosis"] = codes, pcodes, texts
