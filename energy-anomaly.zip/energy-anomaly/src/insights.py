"""Task 3 - actionable insights: excess energy (kWh), cost ($), root cause, shift handoff.

    python -m src.insights     # data/scored_telemetry.csv -> outputs/audit_summary.json + shift_handoff.md

Event logic:
  * performance events come from `perf_alarm` and are merged by WALL-CLOCK minutes (rows are a
    complete 1-minute grid), so an event never silently spans a standby period;
  * sensor-freeze and out-of-range readings are separate data-quality events (no energy cost);
  * drift energy is costed retroactively from the estimated onset (when the 6 h median residual
    first exceeded 2%), not only from the first alarm, and no minute is costed twice.
"""
from __future__ import annotations

import json
import os

import numpy as np
import pandas as pd

from src.config import (CRITICAL_THRESHOLD, DRIFT_MERGE_GAP, DRIFT_ONSET_RESIDUAL, EVENT_MERGE_GAP,
                        OUTPUTS_DIR, TARIFF_USD_PER_KWH)
from src.data_processor import load_scored
from src.detector import MESSAGES, drift_message
from src.utils import runs, ts


def _segment_code(seg: pd.DataFrame) -> str:
    counts = seg.loc[seg["perf_alarm"], "perf_code"].value_counts()
    code = next((c for c in ("EFFICIENCY_DRIFT", "POWER_SURGE") if counts.get(c, 0) >= 3), "ABNORMAL_OPERATING_POINT")
    resid = seg.loc[seg["status"].eq("RUNNING") & ~seg["bound_violation"].astype(bool), "power_residual_pct"]
    if len(seg) >= 360 and len(resid) > 120:             # long, rising residual => gradual drift
        first, last = resid.iloc[:60].median(), resid.iloc[-60:].median()
        if last > first and last >= 0.05:
            code = "EFFICIENCY_DRIFT"
    return code


def _event(asset, g, s, e, category, code, excess_kwh=0.0, costed_from=None) -> dict:
    seg = g.iloc[s: e + 1]
    eligible = seg["status"].eq("RUNNING") & ~seg["bound_violation"].astype(bool)
    if code == "EFFICIENCY_DRIFT":
        resid = seg.loc[eligible, "power_residual_pct"]
        message = drift_message(asset, float(resid.iloc[-360:].median()) if len(resid) else 0.0)
    else:
        message = MESSAGES.get(code, MESSAGES["ABNORMAL_OPERATING_POINT"])
    peak = float(seg["perf_score" if category == "performance" else "rule_score"].max())
    ev = {
        "asset_id": asset, "category": category,
        "start": ts(seg["timestamp"].iloc[0]), "end": ts(seg["timestamp"].iloc[-1]),
        "duration_min": int(e - s + 1), "peak_score": round(peak, 3),
        "severity": "CRITICAL" if peak >= CRITICAL_THRESHOLD else "WARNING",
        "root_cause": code, "diagnosis": message,
        "mean_power_kw": round(float(seg["power_kw"].mean()), 1),
        "mean_baseline_kw": round(float(seg["baseline_kw"].mean()), 1),
        "excess_kwh": round(excess_kwh, 2), "cost_usd": round(excess_kwh * TARIFF_USD_PER_KWH, 2),
    }
    if costed_from is not None:
        ev["costed_from"] = ts(costed_from)
    return ev


def _performance_events(asset: str, g: pd.DataFrame) -> list[dict]:
    eligible = (g["status"].eq("RUNNING") & ~g["bound_violation"].astype(bool)).to_numpy()
    excess_kw = (g["power_kw"] - g["baseline_kw"]).to_numpy()
    resid = g["power_residual_pct"].where(eligible)
    roll6h = resid.rolling(360, min_periods=60).median().to_numpy()

    segs: list[list] = []
    for s, e in runs(g["perf_alarm"].to_numpy(), EVENT_MERGE_GAP):
        code = _segment_code(g.iloc[s: e + 1])
        if segs and code == "EFFICIENCY_DRIFT" and segs[-1][2] == code and s - segs[-1][1] <= DRIFT_MERGE_GAP:
            segs[-1][1] = e                               # drift alarms flicker at onset: one event
        else:
            segs.append([s, e, code])

    claimed = np.zeros(len(g), dtype=bool)                # every minute is costed at most once
    events: list[dict] = []
    for pass_drift in (True, False):                      # drift first so it claims its retro window
        for s, e, code in segs:
            if (code == "EFFICIENCY_DRIFT") != pass_drift:
                continue
            start = s
            if code == "EFFICIENCY_DRIFT":
                below = np.flatnonzero(roll6h[:s] < DRIFT_ONSET_RESIDUAL)
                start = int(below[-1]) + 1 if len(below) else 0
            rows = np.zeros(len(g), dtype=bool)
            rows[start: e + 1] = True
            rows &= eligible & ~claimed
            claimed |= rows
            kwh = max(float(np.nansum(excess_kw[rows]) / 60.0), 0.0)
            events.append(_event(asset, g, s, e, "performance", code, kwh,
                                 g["timestamp"].iloc[start] if code == "EFFICIENCY_DRIFT" else None))
    return events


def find_events(scored: pd.DataFrame, merge_gap: int = EVENT_MERGE_GAP) -> list[dict]:
    events: list[dict] = []
    for asset, g in scored.sort_values(["asset_id", "timestamp"]).groupby("asset_id", sort=False):
        g = g.reset_index(drop=True)
        for col, code in (("sensor_frozen", "SENSOR_FREEZE"), ("bound_violation", "DATA_QUALITY")):
            for s, e in runs(g[col].astype(bool).to_numpy(), merge_gap):
                events.append(_event(asset, g, s, e, "data_quality", code))
        events += _performance_events(asset, g)
    events.sort(key=lambda ev: (ev["start"], ev["asset_id"]))
    return events


def audit(scored: pd.DataFrame) -> dict:
    events = find_events(scored)
    total_kwh = round(sum(e["excess_kwh"] for e in events), 2)
    by_asset: dict[str, dict] = {}
    for e in events:
        a = by_asset.setdefault(e["asset_id"], {"events": 0, "excess_kwh": 0.0, "cost_usd": 0.0})
        a["events"] += 1
        a["excess_kwh"] = round(a["excess_kwh"] + e["excess_kwh"], 2)
        a["cost_usd"] = round(a["cost_usd"] + e["cost_usd"], 2)
    alarm = scored["alarm"].astype(bool)
    return {
        "total_records": int(len(scored)),
        "anomalous_records": int(alarm.sum()),                      # records inside an alarm episode
        "critical_alarm_records": int((alarm & (scored["classification"] == "CRITICAL")).sum()),
        "warning_alarm_records": int((alarm & (scored["classification"] == "WARNING")).sum()),
        "anomaly_events": len(events),
        "performance_events": sum(e["category"] == "performance" for e in events),
        "data_quality_events": sum(e["category"] == "data_quality" for e in events),
        "excess_energy_kwh": total_kwh,
        "estimated_cost_usd": round(total_kwh * TARIFF_USD_PER_KWH, 2),
        "tariff_usd_per_kwh": TARIFF_USD_PER_KWH,
        "by_asset": by_asset,
        "flagged_intervals": events,
    }


def template_report(summary: dict, max_items: int = 6) -> str:
    perf = [e for e in summary["flagged_intervals"] if e["category"] == "performance"]
    perf.sort(key=lambda e: (-e["cost_usd"], e["severity"] != "CRITICAL"))
    dq = [e for e in summary["flagged_intervals"] if e["category"] == "data_quality"]
    lines = ["SHIFT HANDOFF - Asset Energy & Maintenance",
             f"- Records analysed: {summary['total_records']:,}; alarm episodes: {summary['anomaly_events']}",
             f"- Excess energy: {summary['excess_energy_kwh']:,.1f} kWh "
             f"(~${summary['estimated_cost_usd']:,.2f} at ${summary['tariff_usd_per_kwh']}/kWh)",
             "", "Maintenance - priority items:"]
    for e in perf[:max_items]:
        lines.append(f"- [{e['severity']}] {e['asset_id']} {e['start']} -> {e['end']} ({e['duration_min']} min, "
                     f"{e['excess_kwh']} kWh / ${e['cost_usd']}): {e['diagnosis']}")
    if len(perf) > max_items:
        lines.append(f"- ...and {len(perf) - max_items} short low-impact episodes (see full audit).")
    lines += ["", "Instrumentation - data quality:"]
    for e in [e for e in dq if e["root_cause"] == "SENSOR_FREEZE"]:
        lines.append(f"- {e['asset_id']} {e['start']} -> {e['end']} ({e['duration_min']} min): {e['diagnosis']}")
    n_bounds = sum(1 for e in dq if e["root_cause"] == "DATA_QUALITY")
    if n_bounds:
        assets = sorted({e["asset_id"] for e in dq if e["root_cause"] == "DATA_QUALITY"})
        lines.append(f"- {n_bounds} out-of-range readings discarded ({', '.join(assets)}): {MESSAGES['DATA_QUALITY']}")
    return "\n".join(lines)


def llm_report(summary: dict) -> str:
    """Optional LLM operator assistant (Task 3.3). Uses Claude when ANTHROPIC_API_KEY is set,
    otherwise - or on any error - the deterministic template. NOTE: the diagnostics summary is
    sent to the external API when enabled; set DISABLE_LLM=1 to keep everything local."""
    if os.getenv("DISABLE_LLM", "").lower() in ("1", "true", "yes") or not os.getenv("ANTHROPIC_API_KEY"):
        return template_report(summary)
    try:
        import anthropic
    except ImportError:
        return template_report(summary)

    payload = {k: v for k, v in summary.items() if k not in ("flagged_intervals", "shift_handoff")}
    perf = [e for e in summary["flagged_intervals"] if e["category"] == "performance"]
    payload["top_performance_events"] = sorted(perf, key=lambda e: -e["cost_usd"])[:10]
    payload["sensor_freezes"] = [e for e in summary["flagged_intervals"] if e["root_cause"] == "SENSOR_FREEZE"]
    payload["out_of_range_readings"] = sum(e["root_cause"] == "DATA_QUALITY" for e in summary["flagged_intervals"])
    prompt = ("You are writing a shift handoff for field maintenance technicians at an industrial plant "
              "(Chiller-01, Compressor-02, Pump-03). Using ONLY the diagnostic data below, write a crisp "
              "bulleted report: (1) headline with total excess energy and cost, (2) prioritised action list - "
              "one bullet per asset issue with time window, what happened, and the maintenance action, "
              "(3) data-quality issues to hand to the instrumentation team. Merge repeated episodes of the same "
              "issue. Do not invent numbers. Max 200 words.\n\n"
              f"<diagnostics>\n{json.dumps(payload, indent=1, default=str)}\n</diagnostics>")
    try:
        client = anthropic.Anthropic()
        response = client.messages.create(model=os.getenv("LLM_MODEL", "claude-sonnet-5-5"), max_tokens=1500,
                                          messages=[{"role": "user", "content": prompt}])
        text = "".join(b.text for b in response.content if getattr(b, "type", "") == "text").strip()
        return text or template_report(summary)
    except Exception:                                   # never break the pipeline for a report
        return template_report(summary)


def main(argv=None) -> None:
    summary = audit(load_scored())
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    (OUTPUTS_DIR / "audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    report = llm_report(summary)
    (OUTPUTS_DIR / "shift_handoff.md").write_text(report + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k != "flagged_intervals"}, indent=2))
    print()
    print(report)


if __name__ == "__main__":
    main()
