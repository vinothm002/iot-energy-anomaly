"""Task 2.2/2.3 - train, calibrate, serialise and evaluate the anomaly detector.

    python -m src.train [--fresh-seed 7]

Pipeline: raw -> clean -> fit per-asset model on healthy RUNNING data (first 2.5 days) ->
calibrate the 0-1 score on held-out healthy minutes -> save models/anomaly_detector.joblib ->
score all telemetry -> evaluate on the hold-out window AND on a freshly generated dataset.
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

from src.config import (ASSET_IDS, ASSETS, CALIB_FRACTION, CLEAN_PATH, DAYS, LABELS_PATH, MODEL_FEATURES,
                        MODEL_PATH, OUTPUTS_DIR, SCORED_PATH, SEED, TRAIN_DAYS)
from src.data_processor import clean, load_raw, save_clean, save_scored
from src.detector import AnomalyDetector, AssetModel, calibration_anchors
from src.evaluate import evaluate, evaluation_markdown
from src.generate_data import generate


def training_mask(df: pd.DataFrame) -> pd.Series:
    """Healthy RUNNING minutes inside the reference window; no freezes, outliers or imputed rows."""
    cutoff = df["timestamp"].min() + pd.Timedelta(days=TRAIN_DAYS)
    return (df["status"].eq("RUNNING") & (df["timestamp"] < cutoff)
            & ~df["sensor_frozen"].astype(bool) & ~df["bound_violation"].astype(bool)
            & ~df["was_imputed"].astype(bool) & ~df["data_gap"].astype(bool))


def fit(df: pd.DataFrame, seed: int = SEED, verbose: bool = True) -> AnomalyDetector:
    mask = training_mask(df)
    t0 = df["timestamp"].min()
    calib_start = t0 + pd.Timedelta(days=TRAIN_DAYS * (1 - CALIB_FRACTION))
    assets: dict[str, AssetModel] = {}
    for asset in ASSET_IDS:
        train = df[mask & df["asset_id"].eq(asset)].copy()
        if len(train) < 200:
            raise RuntimeError(f"not enough healthy RUNNING data to train {asset} ({len(train)} rows)")
        ratio = train["flow_rate"] / ASSETS[asset]["nominal_flow"]
        coefs = np.polyfit(ratio, train["power_kw"], deg=3)                 # physics baseline
        train["baseline_kw"] = np.polyval(coefs, ratio)
        train["power_residual_pct"] = (train["power_kw"] - train["baseline_kw"]) / train["baseline_kw"]

        fit_part = train[train["timestamp"] < calib_start]
        calib = train[train["timestamp"] >= calib_start]                    # held-out healthy data
        scaler = StandardScaler().fit(fit_part[MODEL_FEATURES].to_numpy())
        forest = IsolationForest(n_estimators=300, max_samples=512, contamination="auto",
                                 random_state=seed).fit(scaler.transform(fit_part[MODEL_FEATURES].to_numpy()))
        raw_calib = -forest.score_samples(scaler.transform(calib[MODEL_FEATURES].to_numpy()))
        resid = calib["power_residual_pct"]
        assets[asset] = AssetModel(
            scaler=scaler, model=forest, baseline_coefs=coefs, anchors=calibration_anchors(raw_calib),
            flow_min=float(train["flow_rate"].min()), flow_max=float(train["flow_rate"].max()),
            flow_p01=float(train["flow_rate"].quantile(0.01)), flow_p99=float(train["flow_rate"].quantile(0.99)),
            resid_sigma=float(1.4826 * (resid - resid.median()).abs().median()))
        if verbose:
            print(f"  {asset:14s} fit on {len(fit_part):,} / calibrated on {len(calib):,} healthy RUNNING minutes "
                  f"(residual sigma {assets[asset].resid_sigma:.2%})")
    meta = {"trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "train_window_days": TRAIN_DAYS, "calibration_fraction": CALIB_FRACTION,
            "algorithm": "per-asset IsolationForest(300) + cubic physics baseline residual + 24h drift + rules",
            "features": MODEL_FEATURES}
    return AnomalyDetector(assets, meta)


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="Train + evaluate the anomaly detector")
    p.add_argument("--fresh-seed", type=int, default=SEED + 1, help="seed of the unseen dataset used for evaluation")
    args = p.parse_args(argv)

    df, rep = clean(load_raw())          # always re-clean so data and model can never go out of sync
    save_clean(df)
    print(f"Cleaned telemetry -> {CLEAN_PATH}  ({rep['missing_timestamps_restored']} missing timestamps restored, "
          f"{rep['bound_violations']} bound violations, {rep['frozen_sensor_minutes']} frozen-sensor minutes)")

    print("Training anomaly detector...")
    detector = fit(df)
    detector.save()
    print(f"Saved model -> {MODEL_PATH}")

    scored = detector.score(df)
    save_scored(scored)
    print(f"Scored telemetry -> {SCORED_PATH}")

    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    if not LABELS_PATH.exists():
        print("(no anomaly_labels.csv found - skipping evaluation)")
        return
    labels = pd.read_csv(LABELS_PATH)
    cutoff = df["timestamp"].min() + pd.Timedelta(days=TRAIN_DAYS)
    result = {"temporal_holdout": evaluate(scored, labels, since=cutoff)}

    raw2, labels2 = generate(args.fresh_seed, DAYS)
    df2, _ = clean(raw2)
    result["fresh_seed"] = {"seed": args.fresh_seed, **evaluate(detector.score(df2), labels2)}

    (OUTPUTS_DIR / "evaluation.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    md = evaluation_markdown(result)
    (OUTPUTS_DIR / "evaluation.md").write_text(md, encoding="utf-8")
    print(md)


if __name__ == "__main__":
    main()
