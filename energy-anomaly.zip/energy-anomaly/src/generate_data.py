"""Task 1.1/1.2 - synthetic telemetry generator with realistic dirty-data injection.

    python -m src.generate_data [--seed 42] [--days 7]

Writes data/raw_telemetry.csv and data/anomaly_labels.csv (ground truth for evaluation).

Each machine gets a 7-day, 1-minute grid (10,080 minutes). The communication dropout that
*deletes* rows removes 15-30 of them from the raw file, so the raw CSV has slightly fewer
than 10,080 rows per machine - that is the "missing timestamps" defect. The cleaning step
restores the full 10,080-row grid.
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from src.config import (ASSET_IDS, ASSETS, DATA_DIR, DAYS, LABELS_PATH, MIN_DAYS, MIN_PER_DAY,
                        NUMERIC_COLUMNS, RAW_COLUMNS, RAW_PATH, SEED, START)
from src.utils import ts

_START = pd.Timestamp(START)


def _at(day: int, hour: int, minute: int = 0) -> int:
    return day * MIN_PER_DAY + hour * 60 + minute


# (asset, kind, start_minute, duration_min, params)
FAULTS = [
    ("Pump-03", "sensor_freeze", _at(1, 9), 60, {"column": "return_temp_c"}),
    ("Compressor-02", "sensor_freeze", _at(3, 15), 55, {"column": "return_temp_c"}),
    ("Chiller-01", "sensor_freeze", _at(5, 10), 50, {"column": "supply_temp_c"}),
    ("Chiller-01", "power_surge", _at(3, 16), 25, {"factor": 1.40}),
    ("Compressor-02", "power_surge", _at(4, 11), 20, {"factor": 1.45}),
    ("Pump-03", "power_surge", _at(6, 14, 30), 20, {"factor": 1.50}),
    ("Chiller-01", "efficiency_drift", _at(4, 0), None, {"ramp_hours": 48, "rise": 0.25}),
    ("Compressor-02", "efficiency_drift", _at(4, 12), None, {"ramp_hours": 48, "rise": 0.22}),
]


def _status_schedule(asset: str, minutes: np.ndarray) -> np.ndarray:
    hour = (minutes % MIN_PER_DAY) / 60.0
    day = minutes // MIN_PER_DAY
    status = np.full(minutes.shape, "RUNNING", dtype=object)
    if asset == "Chiller-01":
        status[(hour >= 2) & (hour < 4)] = "STANDBY"
    elif asset == "Compressor-02":
        status[hour < 5] = "STANDBY"
    elif asset == "Pump-03":
        status[(day == 3) & (hour >= 12) & (hour < 14)] = "OFF"
    return status


def _ar(rng: np.random.Generator, n: int, sd: float, phi: float = 0.995) -> np.ndarray:
    out = np.zeros(n)
    eps = rng.normal(0, sd, n)
    for i in range(1, n):
        out[i] = phi * out[i - 1] + eps[i]
    return out


def _load_profile(rng: np.random.Generator, n: int) -> np.ndarray:
    m = np.arange(n)
    daily = 0.75 + 0.15 * np.sin(2 * np.pi * (m / MIN_PER_DAY - 0.375))
    return np.clip(daily + _ar(rng, n, 0.006, phi=0.97), 0.5, 0.98)


def expected_power(asset: str, flow_ratio: np.ndarray) -> np.ndarray:
    """Ground-truth healthy power curve used by the generator (the model never sees this)."""
    rated = ASSETS[asset]["rated_kw"]
    if asset == "Chiller-01":
        return rated * (0.12 + 0.78 * flow_ratio ** 1.3)
    if asset == "Compressor-02":
        return rated * (0.25 + 0.70 * flow_ratio)
    return rated * (0.10 + 0.85 * flow_ratio ** 3)        # pump affinity law


def _healthy_asset(asset: str, rng: np.random.Generator, n: int) -> pd.DataFrame:
    spec = ASSETS[asset]
    minutes = np.arange(n)
    status = _status_schedule(asset, minutes)
    load = _load_profile(rng, n)
    running = status == "RUNNING"

    flow_ratio = load * (1 + rng.normal(0, 0.01, n))
    flow = spec["nominal_flow"] * flow_ratio
    power = expected_power(asset, flow_ratio) * (1 + rng.normal(0, 0.015, n))

    supply = spec["supply_temp"] + 0.3 * (load - 0.75) + _ar(rng, n, 0.015) + rng.normal(0, 0.06, n)
    delta_t = spec["design_delta_t"] * (0.55 + 0.55 * load) + np.sign(spec["design_delta_t"]) * _ar(rng, n, 0.035)
    return_t = supply + delta_t + rng.normal(0, 0.06, n)
    pressure = spec["pressure"] * (0.9 + 0.15 * load) + _ar(rng, n, 0.004 * spec["pressure"]) + rng.normal(0, 0.02, n)

    standby, off = status == "STANDBY", status == "OFF"
    idle_kw = {"Chiller-01": 0.06, "Compressor-02": 0.20, "Pump-03": 0.0}[asset] * spec["rated_kw"]
    power[standby] = idle_kw * (1 + rng.normal(0, 0.03, standby.sum()))
    power[off] = np.abs(rng.normal(0, 0.05, off.sum()))
    flow[~running] = np.abs(rng.normal(0, 0.5, (~running).sum()))
    pressure[~running] = spec["pressure"] * 0.3 + rng.normal(0, 0.02, (~running).sum())
    idle_temp = 22.0 if asset != "Chiller-01" else spec["supply_temp"] + 3
    supply[~running] = idle_temp + rng.normal(0, 0.06, (~running).sum())
    return_t[~running] = supply[~running] + 0.5 + rng.normal(0, 0.06, (~running).sum())

    return pd.DataFrame({
        "minute": minutes, "asset_id": asset, "power_kw": power, "flow_rate": flow,
        "supply_temp_c": supply, "return_temp_c": return_t, "pressure_bar": pressure, "status": status,
    })


def _label(asset, kind, start_min, end_min, detail, rise=np.nan, ramp_hours=np.nan) -> dict:
    return {
        "asset_id": asset, "anomaly_type": kind,
        "start": ts(_START + pd.Timedelta(minutes=int(start_min))),
        "end": ts(_START + pd.Timedelta(minutes=int(end_min))),
        "detail": detail, "rise": rise, "ramp_hours": ramp_hours,
    }


def _inject_faults(df: pd.DataFrame, asset: str, n: int, labels: list[dict]) -> None:
    running = (df["status"] == "RUNNING").to_numpy()
    for f_asset, kind, start, duration, params in FAULTS:
        if f_asset != asset:
            continue
        if kind == "sensor_freeze":
            col = params["column"]
            idx = np.arange(start, start + duration)
            df.loc[idx, col] = df.loc[start, col]
            labels.append(_label(asset, kind, start, start + duration - 1, f"{col} stuck"))
        elif kind == "power_surge":
            idx = np.arange(start, start + duration)
            df.loc[idx, "power_kw"] *= params["factor"]
            pct = round((params["factor"] - 1) * 100)
            labels.append(_label(asset, kind, start, start + duration - 1, f"+{pct}% power, flow unchanged"))
        elif kind == "efficiency_drift":
            ramp = params["ramp_hours"] * 60
            m = np.arange(n)
            factor = 1 + params["rise"] * np.clip((m - start) / ramp, 0, 1) * (m >= start)
            df["power_kw"] *= np.where(running, factor, 1.0)
            pct = round(params["rise"] * 100)
            labels.append(_label(asset, kind, start, n - 1, f"+{pct}% power over {params['ramp_hours']}h at same flow",
                                 rise=params["rise"], ramp_hours=params["ramp_hours"]))


def _pick_free_minutes(rng, n, count, busy: np.ndarray, length: int = 1) -> list[int]:
    picks: list[int] = []
    while len(picks) < count:
        s = int(rng.integers(60, n - length - 60))
        if not busy[max(0, s - 15): s + length + 15].any():
            picks.append(s)
            busy[max(0, s - 15): s + length + 15] = True
    return picks


def _inject_glitches(df: pd.DataFrame, asset: str, rng, n: int, labels: list[dict]) -> np.ndarray:
    """Physical outliers and communication dropouts. Returns a mask of rows to delete."""
    busy = np.zeros(n, dtype=bool)
    for f_asset, kind, start, duration, _ in FAULTS:
        if f_asset == asset and kind != "efficiency_drift":
            busy[max(0, start - 30): start + duration + 30] = True
    busy |= (df["status"] != "RUNNING").to_numpy()

    for s in _pick_free_minutes(rng, n, 10, busy):
        df.loc[s, "power_kw"] = -abs(df.loc[s, "power_kw"])
        labels.append(_label(asset, "physical_outlier", s, s, "negative power"))
    for s in _pick_free_minutes(rng, n, 6, busy):
        col = "supply_temp_c" if rng.random() < 0.5 else "return_temp_c"
        df.loc[s, col] = 999.0
        labels.append(_label(asset, "physical_outlier", s, s, f"{col}=999"))
    for s in _pick_free_minutes(rng, n, 2, busy):
        df.loc[s, "return_temp_c"] = -40.0
        labels.append(_label(asset, "physical_outlier", s, s, "return_temp_c=-40"))

    drop = np.zeros(n, dtype=bool)
    length = int(rng.integers(15, 31))
    (s,) = _pick_free_minutes(rng, n, 1, busy, length)
    drop[s: s + length] = True
    labels.append(_label(asset, "comm_dropout_missing", s, s + length - 1, f"{length} rows missing"))

    length = int(rng.integers(15, 31))
    (s,) = _pick_free_minutes(rng, n, 1, busy, length)
    df.loc[s: s + length - 1, NUMERIC_COLUMNS] = np.nan
    labels.append(_label(asset, "comm_dropout_nan", s, s + length - 1, f"{length} rows NaN"))
    return drop


def generate(seed: int = SEED, days: int = DAYS) -> tuple[pd.DataFrame, pd.DataFrame]:
    if days < MIN_DAYS:
        raise ValueError(f"days must be >= {MIN_DAYS}: the fault schedule spans {MIN_DAYS} days")
    rng = np.random.default_rng(seed)
    n = days * MIN_PER_DAY
    frames, labels = [], []
    for asset in ASSET_IDS:
        df = _healthy_asset(asset, rng, n)
        _inject_faults(df, asset, n, labels)
        drop = _inject_glitches(df, asset, rng, n, labels)
        frames.append(df[~drop])

    raw = pd.concat(frames, ignore_index=True)
    raw["timestamp"] = (_START + pd.to_timedelta(raw["minute"], unit="min")).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    raw = raw.round({"power_kw": 2, "flow_rate": 1, "supply_temp_c": 2, "return_temp_c": 2, "pressure_bar": 3})
    raw = raw.sort_values(["timestamp", "asset_id"])[RAW_COLUMNS].reset_index(drop=True)
    return raw, pd.DataFrame(labels)


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="Generate synthetic dirty telemetry + fault labels")
    p.add_argument("--seed", type=int, default=SEED)
    p.add_argument("--days", type=int, default=DAYS)
    args = p.parse_args(argv)
    raw, labels = generate(args.seed, args.days)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    raw.to_csv(RAW_PATH, index=False)
    labels.to_csv(LABELS_PATH, index=False)
    print(f"Wrote {len(raw):,} rows -> {RAW_PATH}")
    print(f"Wrote {len(labels)} fault labels -> {LABELS_PATH}")
    print(raw.groupby("asset_id").size().rename("rows").to_string())


if __name__ == "__main__":
    main()
