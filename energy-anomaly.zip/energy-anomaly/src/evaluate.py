"""Evaluation of the detector against the injected faults (precision / recall / delay / ablation).

Honesty rules baked in:
  * physical outliers are caught by a hard bounds rule, so they are reported separately and are
    NOT part of the macro recall figures;
  * a drift only counts as "expected to be detectable" once the injected rise reaches
    DRIFT_LABEL_MIN_RISE (5%); alarms on a drifting asset before that count as false alarms;
  * drift "detected" means a SUSTAINED alarm (>=80% of the next 60 running minutes), so one
    unrelated alarm cannot score as a detection.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from src.config import (ALARM_SMOOTHING, DRIFT_LABEL_MIN_RISE, TOLERANCE_AFTER_MIN,
                        TOLERANCE_BEFORE_MIN, WARNING_THRESHOLD)
from src.detector import smooth
from src.utils import runs

DETECTABLE = ["power_surge", "sensor_freeze", "efficiency_drift", "physical_outlier"]
MACRO_TYPES = ["power_surge", "sensor_freeze", "efficiency_drift"]
NAMES = {"power_surge": "Power surge", "sensor_freeze": "Frozen sensor",
         "efficiency_drift": "Efficiency drift", "physical_outlier": "Physical outlier (rule)"}


def build_truth(labels: pd.DataFrame, since: pd.Timestamp | None = None) -> pd.DataFrame:
    lab = labels[labels["anomaly_type"].isin(DETECTABLE)].copy()
    lab["start"] = pd.to_datetime(lab["start"], utc=True)
    lab["end"] = pd.to_datetime(lab["end"], utc=True)
    m = (lab["anomaly_type"] == "efficiency_drift").to_numpy()
    hours = DRIFT_LABEL_MIN_RISE / lab["rise"].astype(float) * lab["ramp_hours"].astype(float)
    minutes = np.where(m, np.nan_to_num(hours.to_numpy() * 60), 0.0).round()
    lab["eval_start"] = lab["start"] + pd.to_timedelta(minutes, unit="min")
    if since is not None:
        lab = lab[lab["start"] >= since]
    return lab.reset_index(drop=True)


def _sustained(g: pd.DataFrame, alarm: np.ndarray, running: np.ndarray, t0: pd.Timestamp):
    m = running & (g["timestamp"] >= t0).to_numpy()
    if m.sum() < 60:
        return None
    al = alarm[m].astype(float)
    fwd = pd.Series(al[::-1]).rolling(60, min_periods=60).mean().to_numpy()[::-1]
    hit = np.flatnonzero(fwd >= 0.8)
    return g.loc[m, "timestamp"].iloc[hit[0]] if len(hit) else None


def compute_metrics(scored: pd.DataFrame, truth: pd.DataFrame, alarm: pd.Series) -> dict:
    tolb, tola = pd.Timedelta(minutes=TOLERANCE_BEFORE_MIN), pd.Timedelta(minutes=TOLERANCE_AFTER_MIN)
    per_type: dict[str, dict] = {}
    tp_minutes, false_eps = 0, 0
    for asset, g in scored.groupby("asset_id"):
        a = alarm.loc[g.index].to_numpy().astype(bool)
        t = g["timestamp"]
        run = g["status"].eq("RUNNING").to_numpy()
        at = truth[truth["asset_id"] == asset]
        in_any = np.zeros(len(g), dtype=bool)
        for r in at.itertuples():
            in_any |= t.between(r.eval_start - tolb, r.end + tola).to_numpy()
        tp_minutes += int((a & in_any).sum())
        false_eps += sum(1 for s, e in runs(a) if not in_any[s: e + 1].any())

        for r in at.itertuples():
            d = per_type.setdefault(r.anomaly_type, {"events": 0, "detected": 0, "minutes": 0,
                                                     "alarm_minutes": 0, "delays": []})
            win = t.between(r.eval_start, r.end).to_numpy().copy()
            if r.anomaly_type == "efficiency_drift":
                win &= run
                hit_ts = _sustained(g, a, run, r.eval_start)
            else:
                tol = t.between(r.eval_start, r.end + tola).to_numpy()
                hit_ts = t[a & tol].min() if (a & tol).any() else None
            d["events"] += 1
            d["minutes"] += int(win.sum())
            d["alarm_minutes"] += int((win & a).sum())
            if hit_ts is not None and not pd.isna(hit_ts):
                d["detected"] += 1
                d["delays"].append((hit_ts - r.start).total_seconds() / 60)

    for d in per_type.values():
        d["event_recall"] = d["detected"] / d["events"]
        d["minute_recall"] = d["alarm_minutes"] / max(d["minutes"], 1)
        d["median_delay_min"] = float(np.median(d["delays"])) if d["delays"] else None
        del d["delays"]

    span = scored.groupby("asset_id")["timestamp"].agg(lambda s: (s.max() - s.min()).total_seconds() / 86400)
    asset_days = float(span.sum())
    alarm_minutes = int(alarm.sum())
    macro = [d for k, d in per_type.items() if k in MACRO_TYPES]
    return {
        "per_type": per_type,
        "alarm_minutes": alarm_minutes,
        "true_positive_minutes": tp_minutes,
        "precision": tp_minutes / alarm_minutes if alarm_minutes else 0.0,
        "false_alarm_episodes": false_eps,
        "false_alarms_per_asset_day": false_eps / asset_days if asset_days else 0.0,
        "macro_event_recall": float(np.mean([d["event_recall"] for d in macro])) if macro else 0.0,
        "macro_minute_recall": float(np.mean([d["minute_recall"] for d in macro])) if macro else 0.0,
    }


def alarm_for(scored: pd.DataFrame, score_col: str, threshold: float) -> pd.Series:
    return (smooth(scored, score_col) >= threshold) | scored["bound_violation"].astype(bool)


def _drift_detail(scored: pd.DataFrame, truth: pd.DataFrame) -> list[dict]:
    rows = []
    for r in truth[truth["anomaly_type"] == "efficiency_drift"].itertuples():
        g = scored[scored["asset_id"] == r.asset_id].reset_index(drop=True)
        g = g[g["timestamp"] >= r.start].reset_index(drop=True)
        a = g["alarm"].to_numpy().astype(bool)
        run = g["status"].eq("RUNNING").to_numpy()
        first_alarm = g.loc[a, "timestamp"].min()
        first_diag = g.loc[a & (g["perf_code"] == "EFFICIENCY_DRIFT").to_numpy(), "timestamp"].min()
        sustained = _sustained(g, a, run, r.start)

        def hrs(t, start=r.start):
            return None if pd.isna(t) else round((t - start).total_seconds() / 3600, 1)

        def rise_at(t, start=r.start, rise=r.rise, ramp=r.ramp_hours):
            return None if pd.isna(t) else round(min((t - start).total_seconds() / 3600 / ramp, 1) * rise * 100, 1)

        rows.append({"asset_id": r.asset_id,
                     "first_alarm_hours": hrs(first_alarm), "injected_rise_at_alarm_pct": rise_at(first_alarm),
                     "sustained_alarm_hours": hrs(sustained), "injected_rise_at_sustained_pct": rise_at(sustained),
                     "first_drift_diagnosis_hours": hrs(first_diag),
                     "injected_rise_at_diagnosis_pct": rise_at(first_diag)})
    return rows


def evaluate(scored: pd.DataFrame, labels: pd.DataFrame, since: pd.Timestamp | None = None) -> dict:
    """Evaluate scored telemetry against labels. `since` restricts to a held-out time window."""
    scored = scored.sort_values(["asset_id", "timestamp"])
    if since is not None:
        scored = scored[scored["timestamp"] >= since]
    scored = scored.reset_index(drop=True)
    truth = build_truth(labels, since)

    report = {"operating_threshold": WARNING_THRESHOLD, "persistence_minutes": ALARM_SMOOTHING,
              "window_start": str(scored["timestamp"].min()), "window_end": str(scored["timestamp"].max()),
              **compute_metrics(scored, truth, scored["alarm"].astype(bool))}
    report["drift_detection"] = _drift_detail(scored, truth)

    report["threshold_sweep"] = []
    for t in np.round(np.arange(0.30, 0.95, 0.05), 2):
        m = compute_metrics(scored, truth, alarm_for(scored, "anomaly_score", float(t)))
        report["threshold_sweep"].append({
            "threshold": float(t), "precision": round(m["precision"], 4),
            "macro_minute_recall": round(m["macro_minute_recall"], 4),
            "macro_event_recall": round(m["macro_event_recall"], 4),
            "false_alarms_per_asset_day": round(m["false_alarms_per_asset_day"], 2)})

    report["ablation"] = {}
    for name, col in (("hybrid (ML + physics + rules)", "anomaly_score"),
                      ("ML only (Isolation Forest + rules)", "score_ml_only"),
                      ("physics only (baseline residual + drift + rules)", "score_physics_only")):
        m = compute_metrics(scored, truth, alarm_for(scored, col, WARNING_THRESHOLD))
        report["ablation"][name] = {
            "precision": round(m["precision"], 4),
            "macro_event_recall": round(m["macro_event_recall"], 4),
            "macro_minute_recall": round(m["macro_minute_recall"], 4),
            "false_alarms_per_asset_day": round(m["false_alarms_per_asset_day"], 2),
            "minute_recall_by_type": {k: round(v["minute_recall"], 3) for k, v in m["per_type"].items()},
        }
    return report


def _fmt(v, suffix=""):
    return "-" if v is None else f"{v}{suffix}"


def section_markdown(rep: dict, title: str) -> str:
    L = [f"### {title}", "",
         f"Window: {rep['window_start'][:16]} -> {rep['window_end'][:16]} UTC; "
         f"alarm = {rep['persistence_minutes']}-minute median of score >= {rep['operating_threshold']:.2f}", "",
         "| Injected fault | Events | Detected | Event recall | Minute recall | Median delay (min from onset) |",
         "|---|---:|---:|---:|---:|---:|"]
    for kind in DETECTABLE:
        d = rep["per_type"].get(kind)
        if d:
            delay = "-" if d["median_delay_min"] is None else f"{d['median_delay_min']:.0f}"
            L.append(f"| {NAMES[kind]} | {d['events']} | {d['detected']} | {d['event_recall']:.0%} | "
                     f"{d['minute_recall']:.0%} | {delay} |")
    L += ["", f"- Macro recall over surge/freeze/drift: event **{rep['macro_event_recall']:.0%}**, "
              f"minute **{rep['macro_minute_recall']:.1%}**",
          f"- Alarm minutes {rep['alarm_minutes']:,}, inside an expected-fault window {rep['true_positive_minutes']:,} "
          f"-> **precision {rep['precision']:.1%}**",
          f"- False-alarm episodes: {rep['false_alarm_episodes']} (**{rep['false_alarms_per_asset_day']:.2f} per asset-day**)", ""]
    if rep["drift_detection"]:
        L += ["| Drift | First alarm (h) | Rise then | Sustained alarm (h) | Rise then | Drift diagnosis (h) | Rise then |",
              "|---|---:|---:|---:|---:|---:|---:|"]
        for d in rep["drift_detection"]:
            L.append(f"| {d['asset_id']} | {_fmt(d['first_alarm_hours'])} | {_fmt(d['injected_rise_at_alarm_pct'], '%')} | "
                     f"{_fmt(d['sustained_alarm_hours'])} | {_fmt(d['injected_rise_at_sustained_pct'], '%')} | "
                     f"{_fmt(d['first_drift_diagnosis_hours'])} | {_fmt(d['injected_rise_at_diagnosis_pct'], '%')} |")
        L.append("")
    return "\n".join(L)


def evaluation_markdown(result: dict) -> str:
    hold = result["temporal_holdout"]
    parts = ["## Evaluation", "", section_markdown(hold, "A. Temporal hold-out (model trained on first 2.5 days; scored on the rest)"), ""]
    if "fresh_seed" in result:
        parts += [section_markdown(result["fresh_seed"], f"B. Fresh dataset (seed {result['fresh_seed']['seed']}, never seen in training)"), ""]
    parts += ["### Ablation (hold-out window): is the Isolation Forest earning its place?", "",
              "| Variant | Precision | Event recall | Minute recall | False alarms / asset-day |", "|---|---:|---:|---:|---:|"]
    for name, a in hold["ablation"].items():
        parts.append(f"| {name} | {a['precision']:.1%} | {a['macro_event_recall']:.0%} | "
                     f"{a['macro_minute_recall']:.1%} | {a['false_alarms_per_asset_day']:.2f} |")
    parts += ["", "### Threshold sweep (hold-out window)", "",
              "| Threshold | Precision | Minute recall | Event recall | False alarms / asset-day |", "|---:|---:|---:|---:|---:|"]
    for s in hold["threshold_sweep"]:
        mark = " **(spec boundary)**" if abs(s["threshold"] - hold["operating_threshold"]) < 1e-9 else ""
        parts.append(f"| {s['threshold']:.2f}{mark} | {s['precision']:.1%} | {s['macro_minute_recall']:.1%} | "
                     f"{s['macro_event_recall']:.0%} | {s['false_alarms_per_asset_day']:.2f} |")
    return "\n".join(parts) + "\n"
