"""Task 2.1 - automated charts written to outputs/.

    python -m src.visualize

  trends.png                  power + flow over time, detected abnormal intervals shaded
  efficiency_correlation.png  power vs flow scatter colour-coded by status, with healthy baseline
  anomalies_detected.png      detected anomalies marked on the power timeline
  drift_residual.png          efficiency drift: power above the healthy baseline over time
  precision_recall.png        alarm-threshold trade-off (hold-out window)
"""
from __future__ import annotations

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.dates as mdates  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from src.config import (ASSET_IDS, ASSETS, DRIFT_RESIDUAL, MODEL_PATH, OUTPUTS_DIR, TRAIN_DAYS)  # noqa: E402
from src.data_processor import load_scored  # noqa: E402
from src.detector import AnomalyDetector  # noqa: E402
from src.utils import runs  # noqa: E402

SERIES = ["#2a78d6", "#eb6834", "#1baf7a"]
STATUS_COLORS = {"RUNNING": SERIES[0], "STANDBY": SERIES[1], "OFF": SERIES[2]}
WARNING_C, CRITICAL_C = "#fab219", "#d03b3b"
INK, MUTED, GRID, SHADE = "#0b0b0b", "#898781", "#e1e0d9", "#d03b3b"

plt.rcParams.update({
    "axes.edgecolor": "#c3c2b7", "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED,
    "axes.titlesize": 11, "axes.titleweight": "bold", "font.size": 9, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False, "axes.spines.right": False,
    "figure.facecolor": "#fcfcfb", "axes.facecolor": "#fcfcfb", "savefig.facecolor": "#fcfcfb",
})


def _spans(g: pd.DataFrame, merge_gap: int = 30) -> list[tuple]:
    mask = (g["alarm"].astype(bool) & ~g["bound_violation"].astype(bool)).to_numpy()
    t = g["timestamp"]
    return [(t.iloc[s], t.iloc[e]) for s, e in runs(mask, merge_gap)]


def _fmt_time(ax):
    ax.xaxis.set_major_locator(mdates.DayLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %d"))


def _train_cutoff(df: pd.DataFrame) -> pd.Timestamp:
    return df["timestamp"].min() + pd.Timedelta(days=TRAIN_DAYS)


def plot_trends(df: pd.DataFrame) -> None:
    fig, axes = plt.subplots(6, 1, figsize=(14, 15), sharex=True)
    cutoff = _train_cutoff(df)
    for i, asset in enumerate(ASSET_IDS):
        g = df[df["asset_id"] == asset].sort_values("timestamp")
        unit = ASSETS[asset]["flow_unit"]
        ax_p, ax_f = axes[2 * i], axes[2 * i + 1]
        ax_p.plot(g["timestamp"], g["power_kw"], color=SERIES[0], lw=0.8)
        ax_p.plot(g["timestamp"], g["rolling_power_mean_1h"], color=INK, lw=1.2, alpha=0.7)
        ax_f.plot(g["timestamp"], g["flow_rate"], color=SERIES[2], lw=0.8)
        for s, e in _spans(g):
            for ax in (ax_p, ax_f):
                ax.axvspan(s, e, color=SHADE, alpha=0.12, lw=0)
        for ax in (ax_p, ax_f):
            ax.axvline(cutoff, color=MUTED, ls=":", lw=1)
        ax_p.set_title(f"{asset} - power draw (kW) with 1h rolling mean")
        ax_p.set_ylabel("kW")
        ax_f.set_title(f"{asset} - flow rate ({unit})")
        ax_f.set_ylabel(unit)
    handles = [plt.Line2D([], [], color=SERIES[0], lw=2, label="power (1-min)"),
               plt.Line2D([], [], color=INK, lw=2, label="power 1h rolling mean"),
               plt.Line2D([], [], color=SERIES[2], lw=2, label="flow (1-min)"),
               plt.Rectangle((0, 0), 1, 1, color=SHADE, alpha=0.25, label="detected abnormal interval"),
               plt.Line2D([], [], color=MUTED, ls=":", lw=1.5, label="end of training window")]
    fig.legend(handles=handles, loc="upper center", ncol=5, frameon=False, bbox_to_anchor=(0.5, 1.0))
    _fmt_time(axes[-1])
    fig.suptitle("Power and flow over time - normal vs abnormal intervals", y=1.015, fontsize=13, fontweight="bold")
    fig.tight_layout()
    fig.savefig(OUTPUTS_DIR / "trends.png", dpi=110, bbox_inches="tight")
    plt.close(fig)


def plot_efficiency(df: pd.DataFrame, detector: AnomalyDetector | None) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    for ax, asset in zip(axes, ASSET_IDS):
        g = df[df["asset_id"] == asset]
        for status, color in STATUS_COLORS.items():
            s = g[g["status"] == status]
            if len(s):
                ax.scatter(s["flow_rate"], s["power_kw"], s=6, color=color, alpha=0.45, lw=0, label=status)
        if detector is not None and asset in detector.assets:
            run = g[g["status"] == "RUNNING"]
            x = np.linspace(run["flow_rate"].quantile(0.005), run["flow_rate"].quantile(0.995), 100)
            ax.plot(x, detector.baseline_kw(asset, x), color=INK, lw=2, label="healthy baseline")
        ax.set_title(asset)
        ax.set_xlabel(f"Flow rate ({ASSETS[asset]['flow_unit']})")
        ax.set_ylabel("Power (kW)")
    handles = [plt.Line2D([], [], ls="", marker="o", ms=8, color=c, label=st) for st, c in STATUS_COLORS.items()]
    handles.append(plt.Line2D([], [], color=INK, lw=2, label="healthy baseline (fitted on reference window)"))
    fig.legend(handles=handles, loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 1.02))
    fig.suptitle("Efficiency correlation - power vs flow by operating status\n"
                 "(points above the baseline at the same flow = wasted energy: surges and drift)",
                 y=1.12, fontsize=12, fontweight="bold")
    fig.tight_layout()
    fig.savefig(OUTPUTS_DIR / "efficiency_correlation.png", dpi=110, bbox_inches="tight")
    plt.close(fig)


def plot_anomalies(df: pd.DataFrame) -> None:
    fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=True)
    for ax, asset in zip(axes, ASSET_IDS):
        g = df[df["asset_id"] == asset].sort_values("timestamp").reset_index(drop=True)
        alarm = g["alarm"].astype(bool)
        ax.plot(g["timestamp"], g["power_kw"], color="#9a9890", lw=0.6, label="power (kW)")
        warn = g[alarm & (g["classification"] == "WARNING")]
        crit = g[alarm & (g["classification"] == "CRITICAL")]
        ax.scatter(warn["timestamp"], warn["power_kw"], s=14, color=WARNING_C, marker="^", lw=0,
                   label="WARNING (score 0.50-0.75)", zorder=3)
        ax.scatter(crit["timestamp"], crit["power_kw"], s=14, color=CRITICAL_C, marker="o", lw=0,
                   label="CRITICAL (score >= 0.75)", zorder=4)
        frozen = g["sensor_frozen"].astype(bool)
        ymax = g["power_kw"].max()
        for _, r in g[frozen & ~frozen.shift(1, fill_value=False)].iterrows():
            ax.annotate("sensor freeze", (r["timestamp"], ymax), fontsize=8, color=MUTED, ha="left", va="top")
        ax.set_title(f"{asset} - detected anomalies")
        ax.set_ylabel("kW")
    axes[0].legend(loc="upper left", frameon=False, ncol=3)
    _fmt_time(axes[-1])
    fig.suptitle("Anomaly detection highlighting (alarms after 5-minute persistence filter)",
                 fontsize=13, fontweight="bold")
    fig.tight_layout()
    fig.savefig(OUTPUTS_DIR / "anomalies_detected.png", dpi=110, bbox_inches="tight")
    plt.close(fig)


def plot_drift(df: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(14, 5))
    for color, asset in zip(SERIES, ASSET_IDS):
        g = df[(df["asset_id"] == asset) & (df["status"] == "RUNNING")].set_index("timestamp")
        r = (g["power_residual_pct"].rolling("60min").median() * 100).resample("1min").asfreq()
        ax.plot(r.index, r, color=color, lw=1.5, label=asset)
    ax.axhline(DRIFT_RESIDUAL * 100, color=MUTED, lw=1, ls="--")
    ax.annotate(f"drift diagnosis threshold (+{DRIFT_RESIDUAL:.0%} 24h median)",
                (df["timestamp"].min(), DRIFT_RESIDUAL * 100), xytext=(4, 4),
                textcoords="offset points", fontsize=8, color=MUTED)
    ax.set_ylabel("Power above healthy baseline (%)")
    ax.set_title("Efficiency drift - 1h median power residual vs physics baseline (RUNNING only)")
    ax.legend(frameon=False, loc="upper left")
    _fmt_time(ax)
    fig.tight_layout()
    fig.savefig(OUTPUTS_DIR / "drift_residual.png", dpi=110, bbox_inches="tight")
    plt.close(fig)


def plot_threshold_sweep(result: dict) -> None:
    rep = result["temporal_holdout"]
    sweep = pd.DataFrame(rep["threshold_sweep"])
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(sweep["macro_minute_recall"], sweep["precision"], color=SERIES[0], lw=2, marker="o", ms=8)
    for _, r in sweep.iterrows():
        if round(r["threshold"], 2) in (0.3, 0.5, 0.65, 0.9):
            ax.annotate(f"t={r['threshold']:.2f}", (r["macro_minute_recall"], r["precision"]),
                        textcoords="offset points", xytext=(8, -12), fontsize=9, color="#52514e")
    chosen = sweep[np.isclose(sweep["threshold"], rep["operating_threshold"])]
    ax.scatter(chosen["macro_minute_recall"], chosen["precision"], s=160, facecolor="none",
               edgecolor=CRITICAL_C, lw=2, zorder=5, label="operating point (spec: WARNING >= 0.50)")
    ax.set_xlabel("Recall (macro, minute-level: surge / freeze / drift)")
    ax.set_ylabel("Precision (alarm minutes inside an expected-fault window)")
    ax.set_title("Alarm threshold trade-off (hold-out window)")
    ax.legend(frameon=False, loc="lower left")
    fig.tight_layout()
    fig.savefig(OUTPUTS_DIR / "precision_recall.png", dpi=130)
    plt.close(fig)


def main(argv=None) -> None:
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    df = load_scored()
    detector = None
    if MODEL_PATH.exists():
        try:
            detector = AnomalyDetector.load()
        except Exception as exc:
            print(f"(baseline curve skipped: {exc})")
    plot_trends(df)
    plot_efficiency(df, detector)
    plot_anomalies(df)
    plot_drift(df)
    eval_path = OUTPUTS_DIR / "evaluation.json"
    if eval_path.exists():
        plot_threshold_sweep(json.loads(eval_path.read_text(encoding="utf-8")))
    print(f"Charts written to {OUTPUTS_DIR}")


if __name__ == "__main__":
    main()
