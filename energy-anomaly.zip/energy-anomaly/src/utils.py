"""Small shared helpers."""
from __future__ import annotations

import numpy as np
import pandas as pd


def ts(t) -> str:
    """Timestamp -> ISO-8601 UTC string."""
    return pd.Timestamp(t).strftime("%Y-%m-%dT%H:%M:%SZ")


def runs(mask, merge_gap: int = 0) -> list[tuple[int, int]]:
    """Inclusive (start, end) positions of True-runs; runs closer than `merge_gap` rows are merged."""
    idx = np.flatnonzero(np.asarray(mask, dtype=bool))
    if not len(idx):
        return []
    breaks = np.flatnonzero(np.diff(idx) > merge_gap + 1)
    return list(zip(np.r_[idx[0], idx[breaks + 1]].tolist(), np.r_[idx[breaks], idx[-1]].tolist()))
