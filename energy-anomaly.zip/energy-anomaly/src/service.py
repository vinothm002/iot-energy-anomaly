"""Framework-free service logic behind the API (unit-testable without FastAPI)."""
from __future__ import annotations

import io
import math

import pandas as pd

from src.data_processor import SchemaError, clean
from src.detector import AnomalyDetector
from src.insights import audit, llm_report
from src.utils import ts

MAX_BATCH_ROWS = 50_000
MAX_UPLOAD_BYTES = 20 * 1024 * 1024
SINGLE_NOTE = "Single-reading mode: sensor freezes and gradual drift need history - use /api/v1/batch-audit."


class ServiceError(Exception):
    def __init__(self, status: int, detail):
        super().__init__(str(detail))
        self.status, self.detail = status, detail


def _num(v):
    if v is None:
        return None
    v = float(v)
    return None if math.isnan(v) or math.isinf(v) else round(v, 4)


def diagnose_reading(det: AnomalyDetector, reading: dict) -> dict:
    raw = pd.DataFrame([reading])
    raw["timestamp"] = raw["timestamp"].astype(str)
    try:
        df, _ = clean(raw)
    except SchemaError as exc:
        raise ServiceError(422, str(exc)) from exc
    if df.empty:
        raise ServiceError(422, "unknown asset_id or unparseable timestamp")
    row = det.score(df, with_history=False).iloc[0]
    excess = None
    if row["status"] == "RUNNING" and not math.isnan(row["power_kw"]):
        excess = max(row["power_kw"] - row["baseline_kw"], 0.0)
    return {
        "asset_id": row["asset_id"], "timestamp": ts(row["timestamp"]),
        "anomaly_score": float(row["anomaly_score"]), "classification": row["classification"],
        "diagnosis_code": row["diagnosis_code"], "diagnosis": row["diagnosis"],
        "baseline_kw": _num(row["baseline_kw"]), "power_residual_pct": _num(row["power_residual_pct"]),
        "excess_kw": _num(excess),
        "features": {k: _num(row[k]) for k in ("delta_t", "specific_energy", "load_ratio", "ml_score")},
        "note": SINGLE_NOTE,
    }


def parse_csv(content: bytes) -> pd.DataFrame:
    if len(content) > MAX_UPLOAD_BYTES:
        raise ServiceError(413, "file too large")
    try:
        return pd.read_csv(io.BytesIO(content))
    except Exception as exc:
        raise ServiceError(422, f"could not parse CSV: {exc}") from exc


def batch_audit_frame(det: AnomalyDetector, raw: pd.DataFrame, include_report: bool = False) -> dict:
    if raw.empty:
        raise ServiceError(422, "no readings supplied")
    if len(raw) > MAX_BATCH_ROWS:
        raise ServiceError(413, f"max {MAX_BATCH_ROWS} rows per request")
    try:
        df, quality = clean(raw)
    except SchemaError as exc:
        raise ServiceError(422, str(exc)) from exc
    if df.empty:
        raise ServiceError(422, "no valid readings for known assets")
    summary = audit(det.score(df))
    summary["data_quality"] = quality
    summary["window"] = {"start": ts(df["timestamp"].min()), "end": ts(df["timestamp"].max())}
    if include_report:
        summary["shift_handoff"] = llm_report(summary)
    return summary
