"""Central configuration: paths, asset specifications, thresholds."""
from __future__ import annotations

import logging
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.getenv("DATA_DIR", ROOT / "data"))
MODELS_DIR = Path(os.getenv("MODELS_DIR", ROOT / "models"))
OUTPUTS_DIR = Path(os.getenv("OUTPUTS_DIR", ROOT / "outputs"))

RAW_PATH = DATA_DIR / "raw_telemetry.csv"
LABELS_PATH = DATA_DIR / "anomaly_labels.csv"
CLEAN_PATH = DATA_DIR / "cleaned_telemetry.csv"
SCORED_PATH = DATA_DIR / "scored_telemetry.csv"
MODEL_PATH = Path(os.getenv("MODEL_PATH", MODELS_DIR / "anomaly_detector.joblib"))

# ---- data generation -------------------------------------------------------------
SEED = 42
START = "2026-10-01T00:00:00Z"
MIN_DAYS = 7                      # the fault schedule is laid out over 7 days
DAYS = 7
FREQ = "1min"
MIN_PER_DAY = 1440

ASSETS: dict[str, dict] = {
    "Chiller-01": {"rated_kw": 350.0, "nominal_flow": 600.0, "flow_unit": "GPM",
                   "supply_temp": 7.0, "design_delta_t": 5.6, "pressure": 4.2},
    "Compressor-02": {"rated_kw": 110.0, "nominal_flow": 650.0, "flow_unit": "CFM",
                      "supply_temp": 35.0, "design_delta_t": -10.0, "pressure": 7.0},
    "Pump-03": {"rated_kw": 45.0, "nominal_flow": 1200.0, "flow_unit": "GPM",
                "supply_temp": 29.0, "design_delta_t": 5.5, "pressure": 3.0},
}
ASSET_IDS = list(ASSETS)
STATUSES = ("RUNNING", "STANDBY", "OFF")

RAW_COLUMNS = ["timestamp", "asset_id", "power_kw", "flow_rate", "supply_temp_c",
               "return_temp_c", "pressure_bar", "status"]
NUMERIC_COLUMNS = ["power_kw", "flow_rate", "supply_temp_c", "return_temp_c", "pressure_bar"]
TEMP_COLUMNS = ["supply_temp_c", "return_temp_c"]

# ---- cleaning --------------------------------------------------------------------
BOUNDS = {
    "power_kw": (0.0, None),
    "flow_rate": (0.0, None),
    "supply_temp_c": (-5.0, 110.0),
    "return_temp_c": (-5.0, 110.0),
    "pressure_bar": (0.0, 50.0),
}
FREEZE_WINDOW = 30          # rolling(window=30).std() == 0
MAX_INTERPOLATE_GAP = 30    # minutes; longer gaps stay NaN (flagged data_gap)

# ---- model -----------------------------------------------------------------------
TRAIN_DAYS = 2.5            # first 2.5 days = "healthy reference" window
CALIB_FRACTION = 0.2        # last 20% of the reference window calibrates the score (out-of-sample)
# load_ratio is power / constant, i.e. a pure rescaling of power_kw within one asset, so it is
# kept as an operator feature but NOT fed to the per-asset model.
MODEL_FEATURES = ["power_kw", "flow_rate", "delta_t", "specific_energy", "pressure_bar",
                  "power_residual_pct"]

WARNING_THRESHOLD = 0.50    # NORMAL < 0.50 <= WARNING < 0.75 <= CRITICAL
CRITICAL_THRESHOLD = 0.75
FREEZE_SCORE = 0.60
BOUND_VIOLATION_SCORE = 0.60

SURGE_RESIDUAL = 0.08       # power >= 8% above baseline at normal flow -> surge
DRIFT_RESIDUAL = 0.08       # 24h median residual >= 8% -> efficiency drift
DRIFT_WINDOW = "24h"
ALARM_SMOOTHING = 5         # alarm = 5-minute rolling median of the score >= threshold
EVENT_MERGE_GAP = 5         # minutes
DRIFT_MERGE_GAP = 360       # drift alarms flicker at onset: merge episodes closer than 6 h
DRIFT_ONSET_RESIDUAL = 0.02 # drift energy is costed from when the 6h median residual passed 2%

# ---- evaluation ------------------------------------------------------------------
DRIFT_LABEL_MIN_RISE = 0.05  # a drift is only "expected to be detectable" once the injected rise >= 5%
TOLERANCE_BEFORE_MIN = 2
TOLERANCE_AFTER_MIN = 10

TARIFF_USD_PER_KWH = float(os.getenv("TARIFF_USD_PER_KWH", "0.12"))

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s | %(message)s")
